package cliente;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javax.swing.JLayeredPane;
import javax.swing.JPanel;

/**
 * Es un JPanel que representa una casa en el juego.
 */
public class CasaCliente extends JPanel implements MouseListener{
	
	public int pos;
	public int x, y;
	public int[] n_piezas = {0, 0, 0, 0};
	public List<Stack<Integer>> piezas = new ArrayList<Stack<Integer>>();
	public boolean posible;
	public boolean nacer;
	public boolean piezaSaliendo;
	public JLayeredPane capasRef;
	Color tint = new Color(0xcbc0d3);
	Color tintposible = new Color(0x785964);
	Color tintSelected = new Color(0x785964);
	Color actual = new Color(0xcbc0d3);
	
	// El constructor de la clase CasaCliente.
	public CasaCliente(int n, int y_n, int x_n, JLayeredPane capas){
		this.setPreferredSize(new Dimension(47, 47));
		this.setBackground(Color.white);
		addMouseListener(this);
		this.pos= n;
		posible = false;
		nacer = false;
		piezaSaliendo = false;
		x = x_n*47;
		y = y_n*47;
		capasRef = capas;
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
		
		if(pos == 0) {
			actual = tint = new Color(0x00e8fc);
			tintposible = new Color(0x00b5c5);
			tintSelected = new Color(0x00b5c5);
		}
		if(pos == 12) {
			actual = tint = new Color(0xf9c846);
			tintposible = new Color(0xc39d38);
			tintSelected = new Color(0xc39d38);
		}
		if(pos == 24) {
			actual = tint = new Color(0xf96e46);
			tintposible = new Color(0xc65838);
			tintSelected = new Color(0xc65838);
		}
		if(pos == 36) {
			actual = tint = new Color(0x0fff95);
			tintposible = new Color(0x0ec172);
			tintSelected = new Color(0x0ec172);
		}
	}
	
	/**
	 * La función `paintComponent` se llama cada vez que el componente necesita ser repintado
	 * 
	 * @param g El objeto Graphics que se pasa.
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		
		//g2d.draw
		g2d.setPaint(actual);
		g2d.fillOval(0, 0, 47, 47);
	}
	
	/**
	 * Esta función establece el color del botón al color que tenía cuando se creó.
	 */
	public void ColorNormal() {
		actual = tint;
		repaint();
	}
	/**
	 * Esta función cambia el color del círculo al color que el usuario haya seleccionado.
	 */
	public void Colorposible() {
		actual = tintposible;
		repaint();
	}
	/**
	 * Cuando el usuario selecciona un color, el color real se establece en el color seleccionado.
	 */
	public void ColorSelected() {
		actual = tintSelected;
		repaint();
	}

	// Un oyente de ratón.
	@Override
	public void mouseClicked(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {
		
		if(ServerConnection.ID == ServerConnection.turnoActual)
		{
			ClientLudo.clicar_casa(pos);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}
}
