package cliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Es una clase que representa una conexión a un servidor.
 */
public class ServerConnection implements Runnable{

	private Socket server;
	private BufferedReader in;
	public PrintWriter out;
	
	public String nombre;
	public static int ID;
	
	public static Grid tablero;
	public static int turnoActual;
	
	// El constructor de la clase.
	public ServerConnection(Socket s, String nome) throws IOException {
		server = s;
		in = new BufferedReader(new InputStreamReader(server.getInputStream()));
		out = new PrintWriter(server.getOutputStream(), true);
		nombre = new String(nome);
	}
	
	/**
	 * Lee la respuesta del servidor y la interpreta.
	 */
	@Override
	public void run() {
		try {
			String serverResponse = in.readLine();
			ID = Integer.valueOf(serverResponse);
			ClientLudo.ID = Integer.valueOf(serverResponse);
			ClientLudo.enviar__nome(nombre);
			while(!ClientLudo.finJuego) {
				serverResponse = in.readLine();
				interpretarMensagem(serverResponse);
				if(serverResponse == null) break;
				
				//System.out.println(serverResponse);
			}
		} catch (Exception e) {
			try {
				DadosCliente.terminal.append("\nUsted fue desconectado." );
				int x;
				DadosCliente.terminal.selectAll();
				x = DadosCliente.terminal.getSelectionEnd();
				DadosCliente.terminal.select(x,x);
			} catch (Exception e1) {
				PantallaConexion.frame.dispose();
			}
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	// Un método que interpreta los mensajes recibidos del servidor.
	private void interpretarMensagem(String msg) throws IOException {
		if(msg.startsWith("STATUS__JOGADORES")) {
			if(msg.charAt(26) == '1') {
				//ClientLudo.enviar__nome(nombre);
				PantallaConexion.frame.dispose();
				tablero = new Grid();
			}
			int[] i = new int[4];
			i[0] = (int)(msg.charAt(18) - '0');
			i[1] = (int)(msg.charAt(20) - '0');
			i[2] = (int)(msg.charAt(22) - '0');
			i[3] = (int)(msg.charAt(24) - '0');
			PantallaConexion.actualizar(ID, i);
			return;
		}
		if(msg.startsWith("ATUALIZAR___DADOS")) {
			turnoActual = (int)(msg.charAt(18) - '0');
			DadosCliente.dado1 = (int)(msg.charAt(20) - '0');
			DadosCliente.dado1usado = false;
			if(msg.charAt(22) == '1')
				DadosCliente.dado1usado = true;
			DadosCliente.dado2usado = false;
			DadosCliente.dado2 = (int)(msg.charAt(24) - '0');
			if(msg.charAt(26) == '1')
				DadosCliente.dado2usado = true;
			Grid.dados.label1.setIcon(Grid.dados.DadoImg[DadosCliente.dado1]);
			Grid.dados.label2.setIcon(Grid.dados.DadoImg[DadosCliente.dado2]);
			Grid.capas.repaint();
			return;
		}
		if(msg.startsWith("COLORIR______CASA")) {
			turnoActual = (int)(msg.charAt(18) - '0');
			int pos = (int)(msg.charAt(20) - '0') * 10;
			pos += (int)(msg.charAt(21) - '0');
			int cor = (int)(msg.charAt(23) - '0');
			switch (cor) {
				case 0:
					Grid.camino[pos].ColorNormal();
					break;
				case 1:
					Grid.camino[pos].Colorposible();
					break;
				case 2:
					Grid.camino[pos].ColorSelected();
					break;
			}
			Grid.capas.repaint();
			return;
		}
		if(msg.startsWith("DISPONIVEL___CASA")) {
			turnoActual = (int)(msg.charAt(18) - '0');
			int pos = (int)(msg.charAt(20) - '0') * 10;
			pos += (int)(msg.charAt(21) - '0');
			int posible = (int)(msg.charAt(23) - '0');
			int nacer = (int)(msg.charAt(25) - '0');
			int piezaSaliendo = (int)(msg.charAt(27) - '0');
			int movimientoIniciado  = (int)(msg.charAt(29) - '0');
			Grid.camino[pos].posible = false;
			if(posible == 1)
				Grid.camino[pos].posible = true;
			Grid.camino[pos].nacer = false;
			if(nacer == 1)
				Grid.camino[pos].nacer = true;
			Grid.camino[pos].piezaSaliendo = false;
			if(piezaSaliendo == 1)
				Grid.camino[pos].piezaSaliendo = true;
			Grid.movimientoIniciado = false;
			if(movimientoIniciado == 1)
				Grid.movimientoIniciado = true;
			return;
		}
		if(msg.startsWith("COLORIR____ORIGEM")) {
			turnoActual = (int)(msg.charAt(18) - '0');
			int cor = (int)(msg.charAt(20) - '0');
			switch (cor) {
				case 0:
					Grid.origens[turnoActual].ColorNormal();
					break;
				case 1:
					Grid.origens[turnoActual].ColorSelected();
					break;
			}
			Grid.capas.repaint();
			return;
		}
		if(msg.startsWith("DISPONIVEL_ORIGEM")) {
			turnoActual = (int)(msg.charAt(18) - '0');
			int posible = (int)(msg.charAt(20) - '0');
			int movimientoIniciado  = (int)(msg.charAt(22) - '0');
			Grid.origens[turnoActual].posible = false;
			if(posible == 1)
				Grid.origens[turnoActual].posible = true;
			Grid.movimientoIniciado = false;
			if(movimientoIniciado == 1)
				Grid.movimientoIniciado = true;
			return;
		}
		if(msg.startsWith("COLORIR____CENTRO")) {
			turnoActual = (int)(msg.charAt(18) - '0');
			int cor = (int)(msg.charAt(20) - '0');
			switch (cor) {
				case 0:
					Grid.centro.Normal();
					break;
				case 1:
					Grid.centro.Selected();
					break;
			}
			Grid.capas.repaint();
			return;
		}
		if(msg.startsWith("DISPONIVEL_CENTRO")) {
			turnoActual = (int)(msg.charAt(18) - '0');
			int posible = (int)(msg.charAt(20) - '0');
			int movimientoIniciado  = (int)(msg.charAt(22) - '0');
			Grid.centro.posible = false;
			if(posible == 1)
				Grid.centro.posible = true;
			Grid.movimientoIniciado = false;
			if(movimientoIniciado == 1)
				Grid.movimientoIniciado = true;
			return;
		}
		if(msg.startsWith("MOVER________pieza")) {
			turnoActual = (int)(msg.charAt(18) - '0');
			int id_cor = (int)(msg.charAt(20) - '0');
			int id_pieza = (int)(msg.charAt(22) - '0');
			char sinal = msg.charAt(24);
			int x = (int)(msg.charAt(25) - '0') * 10;
			x += (int)(msg.charAt(26) - '0');
			if(sinal == '-')
				x *= -1;
			else
				x += (int)(msg.charAt(24) - '0') * 100;
			
			sinal = msg.charAt(28);
			int y = (int)(msg.charAt(29) - '0') * 10;
			y += (int)(msg.charAt(30) - '0');
			if(sinal == '-')
				y *= -1;
			else
				y += (int)(msg.charAt(28) - '0') * 100;
			int img = (int)(msg.charAt(32) - '0');
			PiezasCliente.coordPieza[id_cor][id_pieza][0] = x;
			PiezasCliente.coordPieza[id_cor][id_pieza][1] = y;
			PiezasCliente.p_juntas[id_cor][id_pieza] = img;
			Grid.capas.repaint();
			return;
		}
		if(msg.startsWith("ANIMAR______DADOS")) {
			Grid.dados.animacao();
		}
		if(msg.startsWith("MENSAGEM_CONTROLE")) {
			int comando = (int)(msg.charAt(18) - '0');
			int id = (int)(msg.charAt(20) - '0');
			switch (comando) {
				case 0:
					//encerrar
					break;
				case 1:
					//resetar
					break;
				case 2:
					//vencedor
					Grid.vencedor.setText("<html><p align=center style=\"width:400px\">" + ClientLudo.nombres[id] + " venceu!" + "</p></html>");
					Grid.vencedor.setForeground(ClientLudo.cores[id]);
					Grid.vencedor.setVisible(true);
					Grid.frame.repaint();
					server.close();
					ClientLudo.finJuego = true;
					ClientLudo.pool.shutdown();
					break;
			}
		}
		if(msg.startsWith("ATUALIZAR___NOMES")) {
			int id = (int)(msg.charAt(18) - '0');
			ClientLudo.nombres[id] = msg.substring(20, msg.length());
		}
		if(msg.startsWith("ATUALIZAR____INFO")) {
			DadosCliente.terminal.setForeground(ClientLudo.cores[turnoActual]);
			DadosCliente.terminal.append("\n" + msg.substring(18, msg.length()));
			int x;
			DadosCliente.terminal.selectAll();
			x = DadosCliente.terminal.getSelectionEnd();
			DadosCliente.terminal.select(x,x);
		}
		
	}
		
	/**
	 * Esta función envía un mensaje al servidor.
	 * 
	 * @param msg El mensaje que se enviará al servidor.
	 */
	public void enviarMensagem(String msg) {
		out.println(msg);
	}
	
}
