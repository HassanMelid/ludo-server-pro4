package graficos;
//comentario dummy
import java.awt.Color;
import java.awt.GridLayout;
import java.util.Stack;

import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

/**
 * Es una clase que contiene una matriz 2D de enteros y algunas otras variables.
 */
public class GridTest {
    public static boolean piezaSaliendo;
    static Casa camino[] = new Casa[68];		//Vector con todas las casas del tablero
    static Origen origens[] = new Origen[4];
    static Centro centro = new Centro();
    static int[] cercaCentro = new int[4];
    static boolean movimientoIniciado = false;	//True quando uma pe�a est� sendo movida de uma casa para outra
    static int[][] index = {{-1, -1,	-1,	-1,	-1,	24,	-1,	23,	-1,	22,	-1,	-1,	-1,	-1,	-1},
            {-1, -1,	-1,	-1,	-1,	25,	-1,	58,	-1,	21,	-1,	-1,	-1,	-1,	-1},
            {-1, -1,	-1,	-1,	-1,	26,	-1,	59,	-1,	20,	-1,	-1,	-1,	-1,	-1},
            {-1, -1,	-1,	-1,	-1,	27,	-1,	60,	-1,	19,	-1,	-1,	-1,	-1,	-1},
            {-1, -1,	-1, -1,	-1,	28,	-1,	61,	-1,	18,	-1,	-1,	-1,	-1,	-1},
            {34, 33,	32,	31,	30,	29,	-1,	62,	-1,	17,	16,	15,	14,	13,	12},
            {-1, -1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1},
            {35, 63,	64,	65,	66,	67,	-1,	-1,	-1,	57,	56,	55,	54,	53,	11},
            {-1, -1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1},
            {36, 37,	38,	39,	40,	41,	-1,	52,	-1,	5,	6,	7,	8,	9,	10},
            {-1, -1,	-1,	-1,	-1,	42,	-1,	51,	-1,	4,	-1,	-1,	-1,	-1,	-1},
            {-1, -1,	-1,	-1,	-1,	43,	-1,	50,	-1,	3,	-1,	-1,	-1,	-1,	-1},
            {-1, -1,	-1,	-1,	-1,	44,	-1,	49,	-1,	2,	-1,	-1,	-1,	-1,	-1},
            {-1, -1,	-1,	-1,	-1,	45,	-1,	48,	-1,	1,	-1,	-1,	-1,	-1,	-1},
            {-1, -1,	-1,	-1,	-1,	46,	-1,	47,	-1,	0,	-1,	-1,	-1,	-1,	-1}};
    static Piezas capasPiezas = new Piezas();

    // Creando una cuadrícula de 15x15 cuadrados.
    public GridTest() {

        JLayeredPane capas = new JLayeredPane();	//Organiza los graficos que estan apareciendo por capas
        capas.setBounds(0, 0, 1000, 705);

        JFrame frame = new JFrame();
        frame.add(capas);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.setSize(1000, 745);
        //frame.setLayout(new GridLayout(15, 15, 0, 0));
        //frame.getContentPane().setBackground(Color.white);

        JPanel canvas1 = new JPanel();				//|Utilizado para limitar el tamano que el tablero ocupa
        canvas1.setBounds(0, -5, 705, 710);


        JPanel tablero = new JPanel();
        tablero.setLayout(new GridLayout(15, 15, 0, 0));
        tablero.setBackground(Color.white);
        //tablero.setBounds(0, 0, 705, 705);

        for(int linea = 0; linea <15; linea++) {
            for(int col = 0; col<15; col++) {
                if((col==5 || col==7 || col==9)&&(linea<=5 || linea>=9)) {
                    tablero.add(camino[index[linea][col]] = new Casa(index[linea][col], linea, col, capas));
                }
                else {
                    if((linea==5 || linea==7 || linea==9)&&(col<5 || col>9)) {
                        tablero.add(camino[index[linea][col]] = new Casa(index[linea][col], linea, col, capas));
                    }
                    else {
                        if((col==5 || col==9)&&(linea==7)) {
                            tablero.add(camino[index[linea][col]] = new Casa(index[linea][col], linea, col, capas));
                        }
                        else {
                            JPanel empty = new JPanel();
                            empty.setBackground(Color.white);
                            empty.setBounds(0, 0, 47, 47);
                            tablero.add(empty);
                        }
                    }
                }
            }
        }



        capas.add(capasPiezas);
        capas.add(new Dados());


        capas.add(origens[0] = new Origen(0));
        capas.add(origens[1] = new Origen(1));
        capas.add(origens[2] = new Origen(2));
        capas.add(origens[3] = new Origen(3));

        capas.add(centro);
        Origen.capasRef = capas;
        Centro.capasRef = capas;

        canvas1.add(tablero);
        capas.add(canvas1);

        //frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    /**
     * Si la posición está entre 0 y 12*(4-turno), agregue turno*12 a la posición. Si la posición está
     * entre 12*(4-turno) y 48, reste 12*(4-turno) de la posición. De lo contrario, agregue turno*5 a
     * la posición.
     * 
     * @param pos la posición de la pieza en el tablero
     * @param turno 0 para amarillo, 1 para rojo
     * @return La posición de la pieza en el tablero.
     */
    public static int particular_real(int pos, int turno) {//0, amarillo -> 12
        if(pos>=0 && pos<(12*(4-turno)))
            return (pos+turno*12);
        if(pos>=(12*(4-turno)) && pos<48)
            return (pos-(12*(4-turno)));
        return (pos+turno*5);
    }

    /**
     * Si la posición está entre el inicio del turno del jugador y el final del tablero, devuelva la
     * posición menos el inicio del turno del jugador. Si la posición es anterior al inicio del turno
     * del jugador, devuelve la posición más el inicio del turno del último jugador. De lo contrario,
     * devuelve la posición menos el inicio del turno del jugador.
     * 
     * @param pos la posición de la pieza en el tablero
     * @param turno 0,1,2,3
     * @return La posición de la pieza en el tablero.
     */
    public static int real_particular(int pos, int turno) {//12, amarillo -> 0
        if(pos>=turno*12 && pos<48)
            return (pos-turno*12);
        if(pos<turno*12)
            return (pos+12*(4-turno));
        return (pos-turno*5);
    }

    /**
     * Toma la posición del jugador y el número de pasos que quiere moverse y devuelve la nueva
     * posición del jugador
     * 
     * @param pos la posición del jugador
     * @param n numero de pasos
     * @return La posición del jugador.
     */
    // Método que se utiliza para comprobar si hay colisión entre las piezas del juego.
    // Método que se utiliza para comprobar si hay colisión entre las piezas del juego.
    public static int avancar_casa(int pos, int n) {
        return (particular_real(real_particular(pos, Dados.turno)+n, Dados.turno));
    }

    /**
     * Comprueba si hay más de una pieza en una celda, si es así, las mueve al centro de la celda, si
     * no, las mueve al centro de la celda
     */
    public static void verificar_colision() {
        int[][] shift = {{1, 1}, {1, -1}, {-1, -1}, {-1, 1}};
        for(int k=0; k<68; k++) {
            if(camino[k].n_piezas[0]+camino[k].n_piezas[1]+camino[k].n_piezas[2]+camino[k].n_piezas[3] > 1) {
                for(int i = 0; i<4; i++) {
                    Stack<Integer> aux = new Stack<Integer>();
                    for(int j=0; j<camino[k].n_piezas[i]; j++) {
                        Piezas.coordPieza[i][camino[k].piezas.get(i).peek()][0] = camino[k].x+12*shift[i][0];
                        Piezas.coordPieza[i][camino[k].piezas.get(i).peek()][1] = camino[k].y+12*shift[i][1];
                        aux.push(camino[k].piezas.get(i).pop());
                    }
                    for(int j=0; j<camino[k].n_piezas[i]; j++) {
                        camino[k].piezas.get(i).push(aux.peek());
                        Piezas.p_juntas[i][aux.pop()] = camino[k].n_piezas[i];
                    }
                }
            }
            else {
                for(int i = 0; i<4; i++) {
                    Stack<Integer> aux = new Stack<Integer>();
                    for(int j=0; j<camino[k].n_piezas[i]; j++) {
                        Piezas.coordPieza[i][camino[k].piezas.get(i).peek()][0] = camino[k].x;
                        Piezas.coordPieza[i][camino[k].piezas.get(i).peek()][1] = camino[k].y;
                        aux.push(camino[k].piezas.get(i).pop());
                    }
                    for(int j=0; j<camino[k].n_piezas[i]; j++) {
                        camino[k].piezas.get(i).push(aux.peek());
                        Piezas.p_juntas[i][aux.pop()] = camino[k].n_piezas[i];
                    }
                    //??????????????.......
                }
            }
        }
    }


    /**
     * Si el jugador no tiene piezas en el centro, no puede usar un 6 para sacar una pieza del origen.
     */
    public static void verificar_jugada() {
        switch (cercaCentro[Dados.turno]) {
            case 3:
                if(Dados.dado1 == 6 || ((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado1 > 53) &&
                        (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado1 > 53) &&
                        (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado1 > 53)))
                    Dados.dado1usado = true;
                if(Dados.dado2 == 6 || ((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado2 > 53) &&
                        (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado2 > 53) &&
                        (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado2 > 53)))
                    Dados.dado2usado = true;
                break;
            case 2:
                if(centro.n_piezas[Dados.turno] == 1) {
                    if(Dados.dado1 == 6 || ((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado1 > 53) &&
                            (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado1 > 53) &&
                            (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado1 > 53)))
                        Dados.dado1usado = true;
                    if(Dados.dado2 == 6 || ((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado2 > 53) &&
                            (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado2 > 53) &&
                            (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado2 > 53)))
                        Dados.dado2usado = true;
                }
                if(origens[Dados.turno].dentro == 1) {
                    if((Dados.dado1 == 6 && !Dados.dado1usado) || (Dados.dado2 == 6 && !Dados.dado2usado)) {
                        //Ele pode gastar os dois dados na peca que ta fora.
                    }
                    else {
                        if((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado1 > 53) &&
                                (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado1 > 53) &&
                                (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado1 > 53))
                            Dados.dado1usado = true;
                        if((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado2 > 53) &&
                                (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado2 > 53) &&
                                (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado2 > 53))
                            Dados.dado2usado = true;
                    }
                }
                break;
            case 1:
                if(centro.n_piezas[Dados.turno] == 2) {
                    if(Dados.dado1 == 6 || ((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado1 > 53) &&
                            (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado1 > 53) &&
                            (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado1 > 53)))
                        Dados.dado1usado = true;
                    if(Dados.dado2 == 6 || ((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado2 > 53) &&
                            (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado2 > 53) &&
                            (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado2 > 53)))
                        Dados.dado2usado = true;
                }
                if(origens[Dados.turno].dentro == 2) {
                    if((Dados.dado1 == 6 && !Dados.dado1usado) || (Dados.dado2 == 6 && !Dados.dado2usado)) {
                        //Ele pode gastar os dois dados na peca que ta fora.
                    }
                    else {
                        if((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado1 > 53) &&
                                (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado1 > 53) &&
                                (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado1 > 53))
                            Dados.dado1usado = true;
                        if((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado2 > 53) &&
                                (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado2 > 53) &&
                                (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado2 > 53))
                            Dados.dado2usado = true;
                    }
                }
                if(centro.n_piezas[Dados.turno] == 1 && origens[Dados.turno].dentro == 1) {
                    if((Dados.dado1 == 6 && !Dados.dado1usado) || (Dados.dado2 == 6 && !Dados.dado2usado)) {
                        //Ele pode gastar os dois dados na peca que ta fora.
                    }
                    else {
                        if((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado1 > 53) &&
                                (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado1 > 53) &&
                                (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado1 > 53))
                            Dados.dado1usado = true;
                        if((Piezas.posPieza[Dados.turno][0] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][0], Dados.turno) + Dados.dado2 > 53) &&
                                (Piezas.posPieza[Dados.turno][1] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][1], Dados.turno) + Dados.dado2 > 53) &&
                                (Piezas.posPieza[Dados.turno][2] == -1 ||  real_particular(Piezas.posPieza[Dados.turno][2], Dados.turno) + Dados.dado2 > 53))
                            Dados.dado2usado = true;
                    }
                }
                break;
        }
        if(Dados.dado1usado && Dados.dado2usado)
            Dados.proxTurno();
    }

   /**
    * Es una función que se llama cuando un jugador hace clic en un cuadrado en el tablero.
    * 
    * @param pos la posición del botón pulsado
    */
    public static void clickCasa(int pos) {
        if(camino[pos].nacer == true) {
            if(!Dados.dado1usado && Dados.dado1 == 6) {
                camino[pos].nacer = false;
                camino[pos].n_piezas[Dados.turno]++;
                camino[pos].ColorNormal();
                camino[pos].piezas.get(Dados.turno).push(origens[Dados.turno].piezas.pop());
                origens[Dados.turno].ColorNormal();
                origens[Dados.turno].dentro--;
                movimientoIniciado = false;
                Dados.dado1usado = true;
                Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][0] = camino[pos].x;
                Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][1] = camino[pos].y;
                Piezas.posPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()] = pos;
                verificar_jugada();
                return;
            }
            else {
                camino[pos].nacer = false;
                camino[pos].n_piezas[Dados.turno]++;
                camino[pos].ColorNormal();
                camino[pos].piezas.get(Dados.turno).push(origens[Dados.turno].piezas.pop());
                origens[Dados.turno].ColorNormal();
                origens[Dados.turno].dentro--;
                movimientoIniciado = false;
                Dados.dado2usado = true;
                Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][0] = camino[pos].x;
                Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][1] = camino[pos].y;
                Piezas.posPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()] = pos;
                verificar_jugada();
                return;
            }
        }
        if(camino[pos].posible) {
            if(avancar_casa(pos, -Dados.dado1)>=0 && !Dados.dado1usado && camino[avancar_casa(pos, -Dados.dado1)].piezaSaliendo) {
                camino[pos].ColorNormal();
                camino[pos].posible = false;
                camino[pos].n_piezas[Dados.turno]++;
                camino[pos].piezas.get(Dados.turno).push(camino[avancar_casa(pos, -Dados.dado1)].piezas.get(Dados.turno).pop());
                camino[avancar_casa(pos, -Dados.dado1)].n_piezas[Dados.turno]--;
                camino[avancar_casa(pos, -Dados.dado1)].ColorNormal();
                movimientoIniciado = false;
                camino[avancar_casa(pos, -Dados.dado1)].piezaSaliendo = false;

                if((real_particular(pos, Dados.turno) - Dados.dado1 + Dados.dado2) < 53) {
                    camino[avancar_casa(pos, -Dados.dado1+Dados.dado2)].posible = false;
                    camino[avancar_casa(pos, -Dados.dado1+Dados.dado2)].ColorNormal();
                }
                if(real_particular(pos, Dados.turno) + Dados.dado2 < 53) {
                    camino[avancar_casa(pos, +Dados.dado2)].posible = false;
                    camino[avancar_casa(pos, +Dados.dado2)].ColorNormal();
                }
                Dados.dado1usado = true;
                Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][0] = camino[pos].x;
                Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][1] = camino[pos].y;
                Piezas.posPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()] = pos;

                centro.Normal();
                centro.posible = false;

                camino[pos].kill();
                if(pos >= 48) {
                    cercaCentro[Dados.turno] = 0;
                    for(int i=48; i<53; i++) {
                        cercaCentro[Dados.turno] += camino[particular_real(i, Dados.turno)].n_piezas[Dados.turno];
                    }
                }
                verificar_jugada();

            }
            else {
                if(avancar_casa(pos, -Dados.dado2)>=0 && !Dados.dado2usado && camino[avancar_casa(pos, -Dados.dado2)].piezaSaliendo) {
                    camino[pos].ColorNormal();
                    camino[pos].posible = false;
                    camino[pos].n_piezas[Dados.turno]++;
                    camino[pos].piezas.get(Dados.turno).push(camino[avancar_casa(pos, -Dados.dado2)].piezas.get(Dados.turno).pop());
                    camino[avancar_casa(pos, -Dados.dado2)].n_piezas[Dados.turno]--;
                    camino[avancar_casa(pos, -Dados.dado2)].ColorNormal();
                    movimientoIniciado = false;
                    camino[avancar_casa(pos, -Dados.dado2)].piezaSaliendo = false;

                    if(real_particular(pos, Dados.turno) - Dados.dado2 + Dados.dado1 < 53) {
                        camino[avancar_casa(pos, -Dados.dado2+Dados.dado1)].posible = false;
                        camino[avancar_casa(pos, -Dados.dado2+Dados.dado1)].ColorNormal();
                    }
                    if(real_particular(pos, Dados.turno) + Dados.dado1 < 53) {
                        camino[avancar_casa(pos, +Dados.dado1)].posible = false;
                        camino[avancar_casa(pos, +Dados.dado1)].ColorNormal();
                    }
                    Dados.dado2usado = true;
                    Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][0] = camino[pos].x;
                    Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][1] = camino[pos].y;
                    Piezas.posPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()] = pos;

                    centro.Normal();
                    centro.posible = false;

                    camino[pos].kill();
                    if(pos >= 48) {
                        cercaCentro[Dados.turno] = 0;
                        for(int i=48; i<53; i++) {
                            cercaCentro[Dados.turno] += camino[particular_real(i, Dados.turno)].n_piezas[Dados.turno];
                        }
                    }
                    verificar_jugada();
                }
                else {
                    camino[pos].ColorNormal();
                    camino[pos].posible = false;
                    camino[pos].n_piezas[Dados.turno]++;
                    camino[pos].piezas.get(Dados.turno).push(camino[avancar_casa(pos, -Dados.dado1-Dados.dado2)].piezas.get(Dados.turno).pop());
                    camino[avancar_casa(pos, -Dados.dado1-Dados.dado2)].n_piezas[Dados.turno]--;
                    camino[avancar_casa(pos, -Dados.dado1-Dados.dado2)].ColorNormal();
                    movimientoIniciado = false;
                    camino[avancar_casa(pos, -Dados.dado1-Dados.dado2)].piezaSaliendo = false;

                    camino[avancar_casa(pos, -Dados.dado1)].posible = camino[avancar_casa(pos, -Dados.dado2)].posible = false;
                    camino[avancar_casa(pos, -Dados.dado1)].ColorNormal();
                    camino[avancar_casa(pos, -Dados.dado2)].ColorNormal();
                    Dados.dado1usado = Dados.dado2usado = true;
                    Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][0] = camino[pos].x;
                    Piezas.coordPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()][1] = camino[pos].y;
                    Piezas.posPieza[Dados.turno][camino[pos].piezas.get(Dados.turno).peek()] = pos;

                    centro.Normal();
                    centro.posible = false;

                    camino[pos].kill();
                    if(pos >= 48) {
                        cercaCentro[Dados.turno] = 0;
                        for(int i=48; i<53; i++) {
                            cercaCentro[Dados.turno] += camino[particular_real(i, Dados.turno)].n_piezas[Dados.turno];
                        }
                    }
                    Dados.proxTurno();
                }
            }
        }
        else {
            if(!movimientoIniciado && camino[pos].n_piezas[Dados.turno] > 0) {
                if(!Dados.dado1usado && real_particular(pos, Dados.turno) + Dados.dado1 <= 53) {
                    if(real_particular(pos, Dados.turno) + Dados.dado1 == 53) {
                        //tratar
                        camino[pos].ColorSelected();
                        camino[pos].piezaSaliendo = true;
                        centro.Selected();
                        centro.posible = true;
                        movimientoIniciado = true;

                    }
                    else {
                        camino[pos].ColorSelected();
                        camino[avancar_casa(pos, +Dados.dado1)].ColorPosible();
                        camino[avancar_casa(pos, +Dados.dado1)].posible = true;
                        movimientoIniciado = true;
                        camino[pos].piezaSaliendo = true;
                    }
                }
                if(!Dados.dado2usado && real_particular(pos, Dados.turno) + Dados.dado2 <= 53) {
                    if(real_particular(pos, Dados.turno) + Dados.dado2 == 53) {
                        //tratar
                        camino[pos].ColorSelected();
                        camino[pos].piezaSaliendo = true;
                        centro.Selected();
                        centro.posible = true;
                        movimientoIniciado = true;
                    }
                    else {
                        camino[pos].ColorSelected();
                        camino[avancar_casa(pos, +Dados.dado2)].ColorPosible();
                        camino[avancar_casa(pos, +Dados.dado2)].posible = true;
                        movimientoIniciado = true;
                        camino[pos].piezaSaliendo = true;
                    }
                }
                if(!Dados.dado1usado && !Dados.dado2usado && real_particular(pos, Dados.turno) + Dados.dado1 + Dados.dado2 <= 53) {
                    if(real_particular(pos, Dados.turno) + Dados.dado1 + Dados.dado2 == 53) {
                        //tratar
                        camino[pos].ColorSelected();
                        camino[pos].piezaSaliendo = true;
                        centro.Selected();
                        centro.posible = true;
                        movimientoIniciado = true;
                    }
                    else {
                        camino[pos].ColorSelected();
                        camino[avancar_casa(pos, +Dados.dado1+Dados.dado2)].ColorPosible();
                        camino[avancar_casa(pos, +Dados.dado1+Dados.dado2)].posible = true;
                        movimientoIniciado = true;
                        camino[pos].piezaSaliendo = true;
                    }
                }
            }
            else {
                movimientoIniciado = false;
                for(int i=0; i<68; i++) {
                    camino[i].ColorNormal();
                    camino[i].posible = false;
                    camino[i].piezaSaliendo = false;
                    camino[i].nacer = false;
                    origens[Dados.turno].ColorNormal();
                    centro.Normal();
                    centro.posible = false;
                }
            }
        }
    }


}
