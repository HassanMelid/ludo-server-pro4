package graficos;

import java.awt.Image;

import javax.swing.JPanel;

/**
 * Es una clase que contiene las coordenadas de las piezas y las imágenes de las piezas.
 */
public class Piezas extends JPanel {

    static public int[][][] backup =  {{{11*47+27, 12*47+10}, {12*47, 12*47-20}, {13*47-27, 12*47+10}},
            {{11*47+27, 2*47+10}, {12*47, 2*47-20}, {13*47-27, 2*47+10}},
            {{1*47+27, 2*47+10}, {2*47, 2*47-20}, {3*47-27, 2*47+10}},
            {{1*47+27, 12*47+10}, {2*47, 12*47-20}, {3*47-27, 12*47+10}}};			//Serv?
    static public int[][][] coordPieza = {{{11*47+27, 12*47+10}, {12*47, 12*47-20}, {13*47-27, 12*47+10}},
            {{11*47+27, 2*47+10}, {12*47, 2*47-20}, {13*47-27, 2*47+10}},
            {{1*47+27, 2*47+10}, {2*47, 2*47-20}, {3*47-27, 2*47+10}},
            {{1*47+27, 12*47+10}, {2*47, 12*47-20}, {3*47-27, 12*47+10}}};		//Cli
    static public int[][] posPieza = {{-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}};					//Cli?
    static public int[][] p_juntas = {{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}};								//Serv
    static Image[] img_az = new Image[3], img_am = new Image[3], img_vm = new Image[3], img_vd = new Image[3];

    public Piezas() {
	
}

}

