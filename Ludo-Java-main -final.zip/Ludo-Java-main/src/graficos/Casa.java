package graficos;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javax.swing.JLayeredPane;
import javax.swing.JPanel;

/**
 * Es una clase que representa un cuadrado en el tablero. Tiene un montón de variables que se utilizan
 * para realizar un seguimiento del estado del cuadrado.
 */
public class Casa extends JPanel implements MouseListener{

    public int pos;			//ID de la  posision de esta casa-------------------------------Cli
    public int x, y;																//---Serv?
    public int[] n_piezas = {0, 0, 0, 0};		//Array con numero de piezas de cada cor--Serv
    public List<Stack<Integer>> piezas = new ArrayList<Stack<Integer>>();	//-----------Serv
    public boolean posible;	//Indica se es posible mover una pieza para esta casa-----Serv
    public boolean nacer;	//Indica se � posible mover una pieza para esta casa---------Serv
    public boolean piezaSaliendo;	//Indica se una pieza esta siendo retirada de esta casa------Serv
    public JLayeredPane capasRef;
    Color tint = new Color(0xcbc0d3);
    Color tintposible = new Color(0x785964);
    Color tintSelected = new Color(0x785964);
    Color actual = new Color(0xcbc0d3);		//-----------------------------------Cli
    

 // Creando un nuevo objeto de la clase Casa.
    public Casa(int n, int y_n, int x_n, JLayeredPane capas){
        this.setPreferredSize(new Dimension(50, 50));
        this.setBackground(Color.white);
        addMouseListener(this);
        this.pos= n;
        posible = false;
        nacer = false;
        piezaSaliendo = false;
        x = x_n*50;
        y = y_n*50;
        capasRef = capas;
        piezas.add(new Stack<Integer>());
        piezas.add(new Stack<Integer>());
        piezas.add(new Stack<Integer>());
        piezas.add(new Stack<Integer>());
    }

   /**
    * La función toma un objeto Graphics como parámetro, lo convierte en un objeto Graphics2D,
    * establece la pintura en el color real y luego llena un óvalo con el color.
    * 
    * @param g El objeto Graphics sobre el que dibujar.
    */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        //g2d.draw
        g2d.setPaint(actual);
        g2d.fillOval(0, 0, 50, 50);
    }

    /**
     * Establece el color del botón en el color que tenía antes de hacer clic en él.
     */
    public void ColorNormal() {
        actual = tint;
        repaint();
    }
    public void ColorPosible() {
        actual = tintposible;
        repaint();
    }
    public void ColorSelected() {
        actual = tintSelected;
        repaint();
    }

    /**
     * Si la posición de la pieza no es el origen, entonces para cada jugador, si el número de piezas
     * es mayor que 0 y el jugador no es el jugador actual, mientras el número de piezas sea mayor que
     * 0, establezca las coordenadas de la pieza a las coordenadas de respaldo, establecer la posición
     * de la pieza en -1, disminuir el número de piezas, aumentar el número de piezas en el origen,
     * empujar la pieza al origen y volver a pintar el tablero
     */
    public void kill() {
        if(pos != 0 && pos != 12 && pos != 24 && pos != 36) {
            for(int i=0; i<4; i++) {
                if(n_piezas[i] > 0 && i != Dados.turno) {
                    while(n_piezas[i] > 0) {

                        Piezas.coordPieza[i][piezas.get(i).peek()][0] = Piezas.backup[i][piezas.get(i).peek()][0];
                        Piezas.coordPieza[i][piezas.get(i).peek()][1] = Piezas.backup[i][piezas.get(i).peek()][1];
                        Piezas.posPieza[i][piezas.get(i).peek()] = -1;
                        n_piezas[i]--;
                        GridTest.origens[i].dentro++;
                        GridTest.origens[i].piezas.push(piezas.get(i).peek());
                        Piezas.p_juntas[i][piezas.get(i).pop()] = 1;
                        capasRef.repaint();
                    }
                }
            }
        }
    }

   // Un oyente de ratón.
    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent e) {

        GridTest.clickCasa(pos);
        GridTest.verificar_colision();
        capasRef.repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }
}