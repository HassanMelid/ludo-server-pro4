package graficos;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

/**
 * Es un JPanel que tiene un detector de mouse y algunos otros métodos.
 */
public class Centro extends JPanel implements MouseListener{

    public boolean posible;
    public int[] n_piezas = {0, 0, 0, 0};
    public List<Stack<Integer>> piezas = new ArrayList<Stack<Integer>>();
    public static JLayeredPane capasRef;
    Image img_actual, img_normal, img_selected;
    public static int[][][] posFinal = {{{6*47+25, 8*47-7}, {7*47, 8*47}, {8*47-25, 8*47-7}},
            {{8*47-7, 6*47+25}, {8*47, 7*47}, {8*47-7, 8*47-25}},
            {{6*47+25, 6*47+7}, {7*47, 6*47}, {8*47-25, 6*47+7}},
            {{6*47+7, 6*47+25}, {6*47, 7*47}, {6*47+7, 8*47-25}}};

    // El constructor de la clase Centro.
    public Centro(){
        this.setBounds(6*47, 6*47, 141, 141);
        this.setOpaque(false);
        posible = false;
        addMouseListener(this);
        img_actual = img_normal = new ImageIcon("Centro.png").getImage();
        img_selected = new ImageIcon("CentroSelected.png").getImage();
        piezas.add(new Stack<Integer>());
        piezas.add(new Stack<Integer>());
        piezas.add(new Stack<Integer>());
        piezas.add(new Stack<Integer>());
    }

    /**
     * La función paintComponent se llama cada vez que se actualiza el JPanel
     * 
     * @param g Objeto gráfico
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(img_actual, 0, 0, null);
    }

    /**
     * Cuando el usuario hace clic en el botón, la imagen cambia a la imagen seleccionada.
     */
    public void Selected() {
        img_actual = img_selected;
        repaint();
    }

    /**
     * Esta función establece la imagen en la imagen normal y vuelve a pintar la imagen.
     */
    public void Normal() {
        img_actual = img_normal;
        repaint();
    }



    // Un oyente de ratón para un JPanel.
    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // Comprobando si el valor del dado es superior a 47 y si el dado no ha sido utilizado. Si
        // ambas condiciones son verdaderas, ejecutará el método Normal().
        if(posible) {
            if((53 - Dados.dado1) >= 47 && !Dados.dado1usado && GridTest.camino[GridTest.particular_real(53 - Dados.dado1, Dados.turno)].piezaSaliendo) {
                Normal();
                posible = false;
                n_piezas[Dados.turno]++;
                piezas.get(Dados.turno).push(GridTest.camino[GridTest.particular_real(53 - Dados.dado1, Dados.turno)].piezas.get(Dados.turno).pop());
                GridTest.camino[GridTest.particular_real(53 - Dados.dado1, Dados.turno)].n_piezas[Dados.turno]--;
                GridTest.camino[GridTest.particular_real(53 - Dados.dado1, Dados.turno)].ColorNormal();
                GridTest.piezaSaliendo = false;
                GridTest.camino[GridTest.particular_real(53 - Dados.dado1, Dados.turno)].piezaSaliendo = false;

                GridTest.piezaSaliendo = false;
                for(int i=0; i<68; i++) {
                    GridTest.camino[i].ColorNormal();
                    GridTest.camino[i].posible = false;
                    GridTest.camino[i].piezaSaliendo = false;
                    GridTest.camino[i].nacer = false;
                }

                Dados.dado1usado = true;
                Piezas.coordPieza[Dados.turno][piezas.get(Dados.turno).peek()][0] = posFinal[Dados.turno][piezas.get(Dados.turno).peek()][0];
                Piezas.coordPieza[Dados.turno][piezas.get(Dados.turno).peek()][1] = posFinal[Dados.turno][piezas.get(Dados.turno).peek()][1];
                Piezas.posPieza[Dados.turno][piezas.get(Dados.turno).peek()] = -1;

            }
           // Comprobando si el valor del dado es superior a 47 y si el dado no se usa y si el camino
           // no está vacío. Si todas las condiciones son verdaderas, llamará al método Normal() e
           // incrementará el número de piezas y empujará la pieza a la pila.
            else {
                if((53 - Dados.dado2) >= 47 && !Dados.dado2usado && GridTest.camino[GridTest.particular_real(53 - Dados.dado2, Dados.turno)].piezaSaliendo) {
                    Normal();
                    posible = false;
                    n_piezas[Dados.turno]++;
                    piezas.get(Dados.turno).push(GridTest.camino[GridTest.particular_real(53 - Dados.dado2, Dados.turno)].piezas.get(Dados.turno).pop());
                    GridTest.camino[GridTest.particular_real(53 - Dados.dado2, Dados.turno)].n_piezas[Dados.turno]--;
                    GridTest.camino[GridTest.particular_real(53 - Dados.dado2, Dados.turno)].ColorNormal();
                    GridTest.piezaSaliendo = false;
                    GridTest.camino[GridTest.particular_real(53 - Dados.dado2, Dados.turno)].piezaSaliendo = false;

                    GridTest.piezaSaliendo = false;
                    for(int i=0; i<68; i++) {
                        GridTest.camino[i].ColorNormal();
                        GridTest.camino[i].posible = false;
                        GridTest.camino[i].piezaSaliendo = false;
                        GridTest.camino[i].nacer = false;
                    }

                    Dados.dado2usado = true;
                    Piezas.coordPieza[Dados.turno][piezas.get(Dados.turno).peek()][0] = posFinal[Dados.turno][piezas.get(Dados.turno).peek()][0];
                    Piezas.coordPieza[Dados.turno][piezas.get(Dados.turno).peek()][1] = posFinal[Dados.turno][piezas.get(Dados.turno).peek()][1];
                    Piezas.posPieza[Dados.turno][piezas.get(Dados.turno).peek()] = -1;
                }
                // Un código que se ejecuta cuando el usuario hace clic en el centro del tablero.
                else {
                    Normal();
                    posible = false;
                    n_piezas[Dados.turno]++;
                    piezas.get(Dados.turno).push(GridTest.camino[GridTest.particular_real(53 - Dados.dado1 - Dados.dado2, Dados.turno)].piezas.get(Dados.turno).pop());
                    GridTest.camino[GridTest.particular_real(53 - Dados.dado1 - Dados.dado2, Dados.turno)].n_piezas[Dados.turno]--;
                    GridTest.camino[GridTest.particular_real(53 - Dados.dado1 - Dados.dado2, Dados.turno)].ColorNormal();
                    GridTest.piezaSaliendo = false;
                    GridTest.camino[GridTest.particular_real(53 - Dados.dado1 - Dados.dado2, Dados.turno)].piezaSaliendo = false;

                    GridTest.camino[GridTest.particular_real(53 - Dados.dado1, Dados.turno)].posible = GridTest.camino[GridTest.particular_real(53 - Dados.dado2, Dados.turno)].posible = false;
                    GridTest.camino[GridTest.particular_real(53 - Dados.dado1, Dados.turno)].ColorNormal();
                    GridTest.camino[GridTest.particular_real(53 - Dados.dado2, Dados.turno)].ColorNormal();
                    Dados.dado1usado = Dados.dado2usado = true;
                    Piezas.coordPieza[Dados.turno][piezas.get(Dados.turno).peek()][0] = posFinal[Dados.turno][piezas.get(Dados.turno).peek()][0];
                    Piezas.coordPieza[Dados.turno][piezas.get(Dados.turno).peek()][1] = posFinal[Dados.turno][piezas.get(Dados.turno).peek()][1];
                    Piezas.posPieza[Dados.turno][piezas.get(Dados.turno).peek()] = -1;
                }
            }
            GridTest.cercaCentro[Dados.turno] = 0;
            for(int i = 48; i < 53; i++) {
                GridTest.cercaCentro[Dados.turno] += GridTest.camino[GridTest.particular_real(i, Dados.turno)].n_piezas[Dados.turno];
            }
            GridTest.verificar_colision();
            capasRef.repaint();
            GridTest.verificar_jugada();
        }
    }

    // Un oyente de ratón.
    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }
}