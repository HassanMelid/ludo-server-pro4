package graficos;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Es una clase que extiende JPanel e implementa MouseListener. Tiene un montón de variables estáticas,
 * un montón de ImageIcons y un montón de JLabels
 */
public class Dados extends JPanel implements MouseListener{

    static public int dado1, dado2, turno;						//Valor del dado 1, valor del dado 2 y valor del jugador que esta jugando ahora(1, 2, 3 ou 4 para azul, amarillo, rojo y verde)
    static public boolean dado1usado=true, dado2usado=true;	//Indica se determinado dado ys fue utilizado en la jugada actual
    Random random;
    JLabel label1, label2;								//Icone clicable de los dados 1 y 2
    ImageIcon[] DadoImg;								//Vector que pesee las imagenes de los dados



    // Creando una nueva instancia de la clase Dados.
    public Dados() {
        DadoImg = new ImageIcon[7];
        for(int i=1; i<7; i++) {
            String nombreImg = "Dado" + i + ".png";
            DadoImg[i] = new ImageIcon(nombreImg);
            DadoImg[i] = new ImageIcon(DadoImg[i].getImage().getScaledInstance(70, 70,  java.awt.Image.SCALE_SMOOTH));
        }
        random = new Random();
        turno = 0;
        this.setBackground(Color.white);
        this.setBounds(706, 0, 295, 705);
        this.setLayout(null);

        JPanel molduraDados = new JPanel();
        molduraDados.setBounds(70, 280, 145, 80);
        molduraDados.setLayout(new GridLayout(0, 2, 5, 0));
        molduraDados.setOpaque(false);


        label1 = new JLabel();
        label1.setIcon(DadoImg[6]);
        label1.addMouseListener(this);
        label2 = new JLabel();
        label2.setIcon(DadoImg[6]);
        label2.addMouseListener(this);

        molduraDados.add(label1);
        molduraDados.add(label2);

        this.add(molduraDados);
        this.setVisible(true);
    }

    static public void proxTurno() {
        if(Dados.dado1 == 6 && Dados.dado2 == 6) {
            //repete o turno
        }
        else {
            if(++turno >= 4) {
                turno = 0;
            }
        }
        System.out.println("Jugador actual: " + turno);
    }

   // Un oyente de ratón.
    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent e) {

        if((dado1usado && dado2usado) || (GridTest.origens[turno].dentro + GridTest.centro.n_piezas[turno] == 3 && dado1 != 6 && dado2 != 6)) {
            dado1 = random.nextInt(6) + 1; //Sorteia um numero inteiro entre 0 e 5, em seguida soma 1;
            dado2 = random.nextInt(6) + 1;
            label1.setIcon(DadoImg[dado1]);
            label2.setIcon(DadoImg[dado2]);
            dado1usado = false;
            dado2usado = false;
            System.out.println("       Jugador " + turno + " tiro " + dado1 + " y " + dado2);
            GridTest.verificar_jugada();
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }
}