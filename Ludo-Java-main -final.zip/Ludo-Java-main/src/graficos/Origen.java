package graficos;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Stack;

import javax.swing.JLayeredPane;
import javax.swing.JPanel;

/**
 * Es un JPanel que tiene una pila de enteros y un color.
 */
public class Origen extends JPanel implements MouseListener{

    public int dentro;
    public int cor;
    public boolean posible;
    public Stack<Integer> piezas;
    public Color actual, tint, selectedTint;
    public static JLayeredPane capasRef;

    public Origen(int n){
        //this.setPreferredSize(new Dimension(47, 47));
        //this.setPreferredSize(new Dimension(200, 200));

        cor = n;
        posible = false;
        switch(cor) {
            case 0: actual = tint = new Color(0x00e8fc);
                selectedTint = new Color(0x00b5c5);
                this.setBounds(517, 517, 141, 141);
                break;
            case 1: actual = tint = new Color(0xf9c846);
                selectedTint = new Color(0xc39d38);
                this.setBounds(517, 47, 141, 141);
                break;
            case 2: actual = tint = new Color(0xf96e46);
                selectedTint = new Color(0xc65838);
                this.setBounds(47, 47, 141, 141);
                break;
            case 3: actual = tint = new Color(0x0fff95);
                selectedTint = new Color(0x0ec172);
                this.setBounds(47, 517, 141, 141);
                break;
        }
        this.setBackground(Color.white);
        addMouseListener(this);
        this.dentro= 3;
        piezas = new Stack<Integer>();
        piezas.push(0);
        piezas.push(1);
        piezas.push(2);
        



    }

    /**
     * La función paintComponent se llama cada vez que se vuelve a pintar el JPanel, y es responsable
     * de dibujar el contenido del JPanel.
     * 
     * @param g Objeto gráfico
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        //g2d.draw

        g2d.setColor(actual);
        g2d.fillOval(0, 0, 141, 141);
    }

    /**
     * Cuando el usuario selecciona un color, el color se establece en el color seleccionado.
     */
    public void ColorSelected() {
        actual = selectedTint;
        repaint();
    }

    /**
     * Cuando el mouse no se desplaza sobre el botón, el color del botón se establece en el color
     * predeterminado.
     */
    public void ColorNormal() {
        actual = tint;
        repaint();
    }



    // Un oyente de ratón.
    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(Dados.dado1 == 6 && !Dados.dado1usado && !GridTest.movimientoIniciado && dentro>0 && Dados.turno == cor) {
            ColorSelected();
            GridTest.camino[GridTest.particular_real(0, Dados.turno)].ColorPosible();
            GridTest.camino[GridTest.particular_real(0, Dados.turno)].nacer = true;
            GridTest.movimientoIniciado = true;
        }
        else {
            if(Dados.dado2 == 6 && !Dados.dado2usado && !GridTest.movimientoIniciado && dentro>0 && Dados.turno == cor) {
                ColorSelected();
                GridTest.camino[GridTest.particular_real(0, Dados.turno)].ColorPosible();
                GridTest.camino[GridTest.particular_real(0, Dados.turno)].nacer = true;
                GridTest.movimientoIniciado = true;
            }
        }
        capasRef.repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }
}