package cliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.net.UnknownHostException;
import javax.swing.*;

/**
 * Es un JFrame con una imagen de fondo, un campo de texto para que el usuario ingrese su nombre, un
 * campo de texto para que el usuario ingrese la dirección IP del servidor y un botón para conectarse
 * al servidor.
 */
public class PantallaInicial implements ActionListener{

	static JFrame frame = new JFrame();
	JButton boton = new JButton("Conectar");
	URL url = getClass().getResource("/resource/PantallaInicialLudo.png");
	ImageIcon fondo = new ImageIcon(url);
	JLabel fondoLabel = new JLabel();
	JLabel error = new JLabel();
	
	private static JTextField nombre;
	private static JTextField direccionIP;
	
	// El constructor de la clase PantallaInicial.
	PantallaInicial() {
		
		// Crear un JFrame con una imagen de fondo, un campo de texto para que el usuario ingrese su nombre,
		// un campo de texto para que el usuario ingrese la dirección IP del servidor y un botón para
		// conectarse al servidor.
		frame.setTitle("LUDO-PRO4");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setSize(1000, 745);
		frame.setLocationRelativeTo(null);
		
		JLayeredPane capas = new JLayeredPane();
		capas.setBounds(0, 0, 1000, 745);
		error.setBounds(100, 600, 800, 40);
		error.setHorizontalAlignment(JLabel.CENTER);
		error.setForeground(new Color(0xe86b67));
		error.setFont(new Font("Arial", Font.BOLD, 15));
		capas.add(error);
		frame.add(capas);
		
		fondoLabel.setIcon(fondo);
		fondoLabel.setBounds(0, -40, 1000, 745);
		
		boton.setBounds(17, 560, 254, 39);
		boton.setFocusable(false);
		boton.addActionListener(introducir);
		boton.setBackground(new Color(0xea374d));
		boton.setForeground(Color.white);
		boton.setFont(new Font("Arial", Font.BOLD, 15));
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		
		nombre = new JTextField();
		nombre.setBounds(17, 381, 254, 39);
		nombre.setBackground(Color.white);
		nombre.setBorder(null);
		nombre.setFont(new Font("Arial", Font.PLAIN, 20));
		
		direccionIP = new JTextField();
		direccionIP.setBounds(17, 475, 254, 39);
		direccionIP.addActionListener(introducir);
		direccionIP.setBackground(Color.white);
		direccionIP.setBorder(null);
		direccionIP.setFont(new Font("Arial", Font.PLAIN, 20));
		
		panel.add(nombre);
		panel.add(direccionIP);
		panel.setOpaque(false);
		panel.setBounds(350, 0, 300, 745);
		panel.add(boton);
		
		capas.add(panel);
		capas.add(fondoLabel);
		
		frame.setVisible(true);
	}

	
	// Una clase anónima que implementa la interfaz Action.
	Action introducir = new AbstractAction()
	{
	    @Override
	    public void actionPerformed(ActionEvent e)
	    {
	    	String nick = nombre.getText();
	    	if(nick.isBlank())
	    		nick = "Usuario";
	    	try {
	    		ClientLudo.Conectar(direccionIP.getText(), nick);
			} catch (UnknownHostException e1) {
				error.setText("Introduzca IP valido e intente nuevamente.");
			} catch (IOException e1) {
				error.setText("Problema de Conexion. intente nuevamente.");
			}
	    }
	};

	@Override
	public void actionPerformed(ActionEvent e) {}
	
}
