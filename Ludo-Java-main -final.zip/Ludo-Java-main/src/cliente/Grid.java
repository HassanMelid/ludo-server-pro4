package cliente;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Grid {
    public static PiezasCliente coordPieza;
    static CasaCliente camino[] = new CasaCliente[68];		//Vcetor con todas las casas del tablero
	static OrigenCliente origens[] = new OrigenCliente[4];
	static CentroCliente centro = new CentroCliente();
	static JLayeredPane camadas;
	static JLabel vencedor;
	static DadosCliente dados;
	static JButton salir;
	static JFrame frame;
	static int[] pertoCentro = new int[4];
	static boolean movimientoIniciado = false;	//True cuando una pieza esta sendo movida de una casa para otra
	static int[][] index = {{-1, -1,	-1,	-1,	-1,	24,	-1,	23,	-1,	22,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	25,	-1,	58,	-1,	21,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	26,	-1,	59,	-1,	20,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	27,	-1,	60,	-1,	19,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1, -1,	-1,	28,	-1,	61,	-1,	18,	-1,	-1,	-1,	-1,	-1},
					 		{34, 33,	32,	31,	30,	29,	-1,	62,	-1,	17,	16,	15,	14,	13,	12},
					 		{-1, -1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1},
					 		{35, 63,	64,	65,	66,	67,	-1,	-1,	-1,	57,	56,	55,	54,	53,	11},
					 		{-1, -1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1},
					 		{36, 37,	38,	39,	40,	41,	-1,	52,	-1,	5,	6,	7,	8,	9,	10},
					 		{-1, -1,	-1,	-1,	-1,	42,	-1,	51,	-1,	4,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	43,	-1,	50,	-1,	3,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	44,	-1,	49,	-1,	2,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	45,	-1,	48,	-1,	1,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	46,	-1,	47,	-1,	0,	-1,	-1,	-1,	-1,	-1}};
	static PiezasCliente camadaPecas = new PiezasCliente();
	
	// *|CURSOR_MARCADOR|*


	public Grid() {
		
		vencedor = new JLabel("<html><p align=center style=\"width:400px\">" + "Jugador " + "Aguiar" + " venció!" + "</p></html>");
		vencedor.setBackground(new Color(0, 0, 0, 90));
		vencedor.setForeground(Color.white);
		vencedor.setOpaque(true);
		vencedor.setVisible(false);
		vencedor.setBounds(0, 0, 705, 705);
		vencedor.setFont(new Font("Arial", Font.BOLD, 70));
		vencedor.setHorizontalAlignment(JLabel.CENTER);
		vencedor.setVerticalAlignment(JLabel.CENTER);
		
		camadas = new JLayeredPane();	//Organiza los graficos que estan apareciendo por capas
		camadas.setBounds(0, 0, 1000, 705);
		camadas.add(vencedor);
		
		frame = new JFrame("LUDO-Cliente-Pro4");
		frame.add(camadas);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setSize(1000, 745);

		
		// Crea boton de salir para salir de la pantalla de conexion
		JButton salir = new JButton("salir");
		salir.setBounds(705, 0, 100, 50);
		salir.setBackground(new Color(0x2dc067));
		salir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new PantallaInicial();
			}
		});
		frame.add(salir);
		camadas.add(salir, 0);

		//crea panel de chat con boton enviar que permita enviar mensajes entre jugadores
		JPanel chat = new JPanel();
		chat.setBounds(705, 50, 300, 220);
		chat.setBackground(new Color(0xE7D8D8));
		chat.setLayout(null);
		camadas.add(chat, 0);
		JTextField chatArea = new JTextField();
		chatArea.setBounds(0, 100, 300, 70);
		chat.add(chatArea);
		JButton enviar = new JButton("Enviar");
		enviar.setBounds(0, 170, 300, 50);
		enviar.setBackground(new Color(0x2dc067));
		enviar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				chatArea.getText();
			}
		});
		chat.add(enviar);


		
		JPanel canvas1 = new JPanel();				//|Utilizado para limitar el tamaño que el tablero ocupa
		canvas1.setBounds(0, -5, 705, 710);
		
		
		JPanel tablero = new JPanel();
		tablero.setLayout(new GridLayout(15, 15, 0, 0));
		tablero.setBackground(Color.white);
		
		for(int lina = 0; lina <15; lina++) {
			for(int col = 0; col<15; col++) {
				if((col==5 || col==7 || col==9)&&(lina<=5 || lina>=9)) {
					tablero.add(camino[index[lina][col]] = new CasaCliente(index[lina][col], lina, col, camadas));
				}
				else {
					if((lina==5 || lina==7 || lina==9)&&(col<5 || col>9)) {
						tablero.add(camino[index[lina][col]] = new CasaCliente(index[lina][col], lina, col, camadas));
					}
					else {
						if((col==5 || col==9)&&(lina==7)) {
							tablero.add(camino[index[lina][col]] = new CasaCliente(index[lina][col], lina, col, camadas));
						}
						else {
							JPanel empty = new JPanel();
							empty.setBackground(Color.white);
							empty.setBounds(0, 0, 47, 47);
							tablero.add(empty);
						}
					}
				}
			}
		}
		
		
		camadas.add(camadaPecas);
		dados = new DadosCliente();
		camadas.add(dados);
		
		camadas.add(origens[0] = new OrigenCliente(0));
		camadas.add(origens[1] = new OrigenCliente(1));
		camadas.add(origens[2] = new OrigenCliente(2));
		camadas.add(origens[3] = new OrigenCliente(3));
		
		camadas.add(centro);
		OrigenCliente.camadasRef = camadas;
		CentroCliente.camadasRef = camadas;
		
		canvas1.add(tablero);
		camadas.add(canvas1);
		
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
	
}


