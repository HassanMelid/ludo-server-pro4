package cliente;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javax.swing.JLayeredPane;
import javax.swing.JPanel;

/**
 * Es un JPanel que representa una casa en el juego.
 */
public class CasaCliente extends JPanel implements MouseListener{
	
	// Una variable que almacena la posición de la casa.
	public int pos;
	// Declarando dos variables, `x` e `y`, ambas de tipo `int`.
	public int x, y;
	// Una matriz de números enteros que almacena el número de piezas en cada casa.
	public int[] n_pecas = {0, 0, 0, 0};
	// Creación de una lista de pilas de enteros.
	public List<Stack<Integer>> piezas = new ArrayList<Stack<Integer>>();
	// Una variable booleana que se utiliza para verificar si es posible mudarse a la casa.
	public boolean posible;
	// Una variable booleana que se utiliza para comprobar si nace una pieza.
	public boolean nacer;
	// Una variable booleana que se utiliza para comprobar si una pieza sale de casa.
	public boolean piezaSaliendo;
	// Una referencia al JLayeredPane que contiene el CasaCliente.
	public JLayeredPane camadasRef;
	// Fijando el color de la casa.
	Color tint = new Color(0xcbc0d3);
	// Fijando el color de la casa.
	Color tintPosible = new Color(0x785964);
	// Fijando el color de la casa.
	Color tintSelected = new Color(0x785964);
	// Fijando el color de la casa.
	Color actual = new Color(0xcbc0d3);
	
	// un constructor
	public CasaCliente(int n, int y_n, int x_n, JLayeredPane camadas){
		this.setPreferredSize(new Dimension(47, 47));
		this.setBackground(Color.white);
		addMouseListener(this);
		this.pos= n;
		posible = false;
		nacer = false;
		piezaSaliendo = false;
		x = x_n*47;
		y = y_n*47;
		camadasRef = camadas;
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
		
		// Fijando los colores de las casas.
		if(pos == 0) {
			actual = tint = new Color(0x00e8fc);
			tintPosible = new Color(0x00b5c5);
			tintSelected = new Color(0x00b5c5);
		}
		if(pos == 12) {
			actual = tint = new Color(0xf9c846);
			tintPosible = new Color(0xc39d38);
			tintSelected = new Color(0xc39d38);
		}
		if(pos == 24) {
			actual = tint = new Color(0xf96e46);
			tintPosible = new Color(0xc65838);
			tintSelected = new Color(0xc65838);
		}
		if(pos == 36) {
			actual = tint = new Color(0x0fff95);
			tintPosible = new Color(0x0ec172);
			tintSelected = new Color(0x0ec172);
		}
	}
	
	/**
	 * La función `paintComponent` se llama cada vez que el componente necesita ser repintado
	 * 
	 * @param g El objeto Graphics que se pasa.
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		
		//g2d.draw
		g2d.setPaint(actual);
		g2d.fillOval(0, 0, 47, 47);
	}
	
	/**
	 * Esta función establece el color del botón al color que tenía cuando se creó.
	 */
	public void ColorNormal() {
		actual = tint;
		repaint();
	}
	/**
	 * Si el usuario hace clic en el botón de color, el color del botón cambiará al color que el usuario
	 * haya elegido.
	 */
	public void ColorPosible() {
		actual = tintPosible;
		repaint();
	}
	/**
	 * Cuando el usuario selecciona un color, el color real se establece en el color seleccionado.
	 */
	public void ColorSelected() {
		actual = tintSelected;
		repaint();
	}

	// Un oyente de ratón.
	@Override
	public void mouseClicked(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {
		
		if(ServerConnection.ID == ServerConnection.turnoActual)
		{
			ClientLudo.clicar_casa(pos);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}
}
