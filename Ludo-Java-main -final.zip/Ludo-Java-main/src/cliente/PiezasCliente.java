package cliente;

import java.awt.Graphics;
import java.awt.Image;

import java.net.URL;


import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * Es una clase que contiene las coordenadas de las piezas, la posición de las piezas y las imágenes de
 * las piezas.
 */
public class PiezasCliente extends JPanel {

	// Una matriz 3D que almacena las coordenadas de las piezas.
	// Una matriz 3D que contiene las coordenadas de las piezas.
	static public int[][][] backup =  {{{11*47+27, 12*47+10}, {12*47, 12*47-20}, {13*47-27, 12*47+10}},
			  					{{11*47+27, 2*47+10}, {12*47, 2*47-20}, {13*47-27, 2*47+10}},
			  					{{1*47+27, 2*47+10}, {2*47, 2*47-20}, {3*47-27, 2*47+10}},
			  					{{1*47+27, 12*47+10}, {2*47, 12*47-20}, {3*47-27, 12*47+10}}};
	// Una matriz 3D que almacena las coordenadas de las piezas.
	static public int[][][] coordPieza = {{{11*47+27, 12*47+10}, {12*47, 12*47-20}, {13*47-27, 12*47+10}},
								  {{11*47+27, 2*47+10}, {12*47, 2*47-20}, {13*47-27, 2*47+10}},
								  {{1*47+27, 2*47+10}, {2*47, 2*47-20}, {3*47-27, 2*47+10}},
								  {{1*47+27, 12*47+10}, {2*47, 12*47-20}, {3*47-27, 12*47+10}}};
	// Una matriz que almacena la posición de las piezas.
	static public int[][] posPieza = {{-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}};
	// Una matriz que almacena la posición de las piezas.
	static public int[][] p_juntas = {{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}};
	URL url = getClass().getResource("/resource/blue.png");
	static Image[] img_az = new Image[3], img_am = new Image[3], img_vm = new Image[3], img_vd = new Image[3];

	// Establecer los límites del panel, configurar el panel para que sea transparente y configurar las
	// imágenes de las piezas.



	/**
	 * Establecer los límites del panel, configurar el panel para que sea transparente y configurar las
	 * imágenes de las piezas.
	 */


	public PiezasCliente() {
		this.setBounds(0, 0, 705, 705);
		this.setOpaque(false);
		URL url = getClass().getResource("/resource/blue.png");
		img_az[0] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/blue.png");
		img_az[1] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/blue.png");
		img_az[2] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/yellow.png");
		img_am[0] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/yellow.png");
		img_am[1] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/yellow.png");
		img_am[2] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/red.png");
		img_vm[0] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/red.png");
		img_vm[1] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/red.png");
		img_vm[2] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/green.png");
		img_vd[0] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/green.png");
		img_vd[1] = new ImageIcon(url).getImage();
		url = getClass().getResource("/resource/green.png");
		img_vd[2] = new ImageIcon(url).getImage();

	}

	/**
	 * Dibuja las imágenes de las piezas en el lugar correcto
	 *
	 * @param g Objeto gráfico
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(img_az[p_juntas[0][0]-1], coordPieza[0][0][0], coordPieza[0][0][1], null);
		g.drawImage(img_az[p_juntas[0][1]-1], coordPieza[0][1][0], coordPieza[0][1][1], null);
		g.drawImage(img_az[p_juntas[0][2]-1], coordPieza[0][2][0], coordPieza[0][2][1], null);

		g.drawImage(img_am[p_juntas[1][0]-1], coordPieza[1][0][0], coordPieza[1][0][1], null);
		g.drawImage(img_am[p_juntas[1][1]-1], coordPieza[1][1][0], coordPieza[1][1][1], null);
		g.drawImage(img_am[p_juntas[1][2]-1], coordPieza[1][2][0], coordPieza[1][2][1], null);

		g.drawImage(img_vm[p_juntas[2][0]-1], coordPieza[2][0][0], coordPieza[2][0][1], null);
		g.drawImage(img_vm[p_juntas[2][1]-1], coordPieza[2][1][0], coordPieza[2][1][1], null);
		g.drawImage(img_vm[p_juntas[2][2]-1], coordPieza[2][2][0], coordPieza[2][2][1], null);

		g.drawImage(img_vd[p_juntas[3][0]-1], coordPieza[3][0][0], coordPieza[3][0][1], null);
		g.drawImage(img_vd[p_juntas[3][1]-1], coordPieza[3][1][0], coordPieza[3][1][1], null);
		g.drawImage(img_vd[p_juntas[3][2]-1], coordPieza[3][2][0], coordPieza[3][2][1], null);
	}


}


