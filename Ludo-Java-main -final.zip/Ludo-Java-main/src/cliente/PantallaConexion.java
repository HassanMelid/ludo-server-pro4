package cliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Es una GUI que muestra el estado de los jugadores en el juego.
 */
public class PantallaConexion implements Runnable, ActionListener{
	
	// Crear un nuevo objeto JFrame y asignarlo a la variable `frame`.
	static JFrame frame = new JFrame();
	// Creando un nuevo botón con el texto "INICIAR" y asignándolo a la variable `botón`.
	static JButton boton = new JButton("INICIAR");
	// Creando un nuevo objeto JPanel y asignándolo a la variable `panel`.
	static JPanel panel = new JPanel();
	
	// Creando una nueva etiqueta para cada jugador.
	static JLabel usted = new JLabel("Jugador " + (ClientLudo.ID+1));
	// Creando una matriz de 4 JLabels.
	static JLabel[] j = new JLabel[4];
	// Creando una nueva matriz de JLabels.
	static JLabel[] j_conect = new JLabel[4];
	// Creando una nueva matriz de JLabels.
	static JLabel[] j_pronto = new JLabel[4];
	
	ServerConnection serverConn;
	static int[] jStatusBackup = {0, 0, 0, 0};

	// El constructor de la clase PantallaConexion.
	PantallaConexion(ServerConnection serverConn) {
		this.serverConn = serverConn;
		frame.setTitle("LUDO-PRO4");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setSize(1000, 745);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setBackground(Color.white);

		// Crea boton de atras para salir de la pantalla de conexion
		JButton botonAtras = new JButton("Atras");
		botonAtras.setBounds(10, 10, 100, 30);
		botonAtras.setFocusable(false);
		botonAtras.setBackground(new Color(0x2dc067));
		botonAtras.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new PantallaInicial();
			}
		});
		frame.add(botonAtras);
		

		
		
		// Configuración de las propiedades del botón.
		boton.setBounds(120, 550, 254, 39);
		boton.setFocusable(false);
		boton.addActionListener(this);
		boton.setBackground(new Color(0x2dc067));
		boton.setForeground(Color.white);
		boton.setFont(new Font("Arial", Font.BOLD, 15));
		
		
		// Establecer el color de fondo del panel en blanco, hacerlo opaco, establecer sus límites, agregarle
		// el botón y establecer su diseño en nulo.
		panel.setBackground(Color.white);
		panel.setOpaque(true);
		panel.setBounds(230, 0, 540, 745);
		panel.add(boton);
		panel.setLayout(null);
		
		// Creando una etiqueta para el jugador.
		usted.setBounds(110, 40, 300, 100);
		usted.setFont(new Font("Arial", Font.BOLD, 30));
		usted.setForeground(new Color(0x2dc067));
		panel.add(usted);
		
		// Crear una etiqueta para cada jugador.
		for(int i = 0; i < 4; i++) {
			j[i] = new JLabel();
			j_conect[i] = new JLabel();
			j_pronto[i] = new JLabel();
			j[i].setBounds(0, 200+70*i, 200, 50);
			j[i].setText("Jugador " + (i+1));
			j[i].setFont(new Font("Arial", Font.BOLD, 30));
			
			j_conect[i].setBounds(170, 200+70*i, 200, 50);
			j_conect[i].setFont(new Font("Arial", Font.BOLD, 30));
			j_conect[i].setForeground(Color.red);
			
			j_pronto[i].setBounds(370, 200+70*i, 200, 50);
			j_pronto[i].setFont(new Font("Arial", Font.BOLD, 30));
			j_pronto[i].setForeground(Color.red);
			
			panel.add(j[i]);
			panel.add(j_conect[i]);
			panel.add(j_pronto[i]);
		}
		
		// Configuración del color del texto.
		j[0].setForeground(new Color(0x00e8fc));
		j[1].setForeground(new Color(0xf9c846));
		j[2].setForeground(new Color(0xf96e46));
		j[3].setForeground(new Color(0x0fff95));
		
		frame.setVisible(true);
		frame.add(panel);
	}

	/**
	 * El servidor llama a esta función para actualizar la GUI del cliente con el estado actual del juego.
	 * 
	 * @param id la identificación del jugador
	 * @param jStatus una matriz de enteros que representa el estado de cada jugador.
	 */
	static public void actualizar(int id, int[] jStatus) {
		usted.setText("Jugador " + (id+1));
		jStatusBackup = jStatus;
	}

	@Override
	public void run() {
		while(true) {
			for(int i = 0; i < 4; i++) {
				switch (jStatusBackup[i]) {
				case 0:
					j_conect[i].setText(" esperando ");
					j_conect[i].setForeground(Color.red);
					j_pronto[i].setText("no, todavia");
					j_pronto[i].setForeground(Color.red);
					break;
				case 1:
					j_conect[i].setText(" conectado ");
					j_conect[i].setForeground(Color.green);
					j_pronto[i].setText("no, todavia");
					j_pronto[i].setForeground(Color.red);
					break;
				case 2:
					j_conect[i].setText(" conectado ");
					j_conect[i].setForeground(Color.green);
					j_pronto[i].setText("listo");
					j_pronto[i].setForeground(Color.green);
					break;
				}
			}
		}
	}

	/**
	 * Cuando se presiona el botón, el cliente envía un mensaje al servidor para iniciar el juego
	 * 
	 * @param e El evento que desencadenó la acción.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		serverConn.enviarMensagem("INICIAR_JOGO " + ClientLudo.ID + " 1");
	}
}
