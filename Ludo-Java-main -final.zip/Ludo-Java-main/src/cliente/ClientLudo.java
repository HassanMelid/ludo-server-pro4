package cliente;

import java.awt.Color;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Es un 192.168.56.1 clientes que se conecta a un servidor y espera un mensaje
 */
public class ClientLudo {

	private static final int SERVER_PORT = 9090;
	public static int ID;
	static boolean finJuego = false;
	static Socket receptor;
	public static ExecutorService pool = Executors.newFixedThreadPool(2);
	static public String[] nombres = {"Azul", "Amarillo", "Rojo", "Verde"};
	static Color[] cores = {new Color(0x0D267E), new Color(0xf9c846), new Color(0xB01913), new Color(0x266427)};
	
	public static PrintWriter out;
	
	/**
	 * La función principal es el punto de entrada del programa.
	 */
	public static void main(String[] args) throws IOException {
		
		new PantallaInicial();
		
	}
	
	/**
	 * Crea un socket, un objeto ServerConnection, un objeto PrintWriter y un objeto PantallaConexion
	 * 
	 * @param insertIP La dirección IP del servidor al que desea conectarse.
	 * @param nombre El nombre del usuario.
	 * @return Un valor booleano.
	 */
	public static boolean Conectar(String insertIP, String nombre) throws UnknownHostException, IOException {
		
		receptor = new Socket (insertIP, SERVER_PORT);
		ServerConnection serverConn = new ServerConnection(receptor, nombre);
		out = new PrintWriter(receptor.getOutputStream(), true);
		pool.execute(serverConn);
		PantallaInicial.frame.dispose();
		PantallaConexion loading = new PantallaConexion(serverConn);
		pool.execute(loading);

		return true;
	}
	
	/**
	 * Envía un mensaje al servidor.
	 * 
	 * @param msg El mensaje que se enviará al servidor.
	 */
	public static void enviarMensagem(String msg) {
		out.println(msg);
	}
	
	/**
	 * Envía un mensaje al servidor para tirar los dados.
	 */
	public static void rolar_dados() {
		enviarMensagem("ROLAR__DADOS " + ID);
	}
	/**
	 * "Envía un mensaje al servidor, diciéndole que haga clic en una casa".
	 * 
	 * La primera línea de la función es un comentario. El compilador ignora los comentarios y se utilizan
	 * para explicar lo que hace el código.
	 * 
	 * @param pos La posición de la casa en la que desea hacer clic.
	 */
	public static void clicar_casa(int pos) {
		String uni = String.format("%02d", pos);
		enviarMensagem("CLICAR__CASA " + ID + " " + uni);
	}
	/**
	 * "Haga clic en el origen del objeto con la ID dada".
	 * 
	 * La primera línea de la función es un comentario. No es necesario, pero es una buena práctica
	 * escribir un comentario explicando qué hace la función.
	 */
	public static void clica_origem() {
		enviarMensagem("CLICA_ORIGEM " + ID);
	}
	/**
	 * Haga clic en el centro del objeto.
	 */
	public static void clica_centro() {
		enviarMensagem("CLICA_CENTRO " + ID);
	}
	/**
	 * Envía un mensaje al servidor para comenzar el juego con la semilla dada.
	 * 
	 * @param s El número de jugadores en el juego.
	 */
	public static void iniciar_jogo(int s) {
		enviarMensagem("INICIAR_JOGO " + ID + " " + s);
	}
	/**
	 * Esta función envía un mensaje al servidor con el comando ENVIAR__NOME, el ID del cliente y el
	 * nombre del cliente.
	 * 
	 * @param nome El nombre del jugador
	 */
	public static void enviar__nome(String nome) {
		enviarMensagem("ENVIAR__NOME " + ID + " " + nome);
	}
}
