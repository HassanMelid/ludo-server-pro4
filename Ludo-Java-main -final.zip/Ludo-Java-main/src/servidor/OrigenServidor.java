package servidor;

import java.util.Stack;
import javax.swing.JLayeredPane;

/**
 * Es una clase que representa un servidor.
 */
public class OrigenServidor {

	// Una variable que representa el número de piezas dentro del servidor.
	public int dentro;
	// Una variable que representa el color del servidor.
	public int cor;
	// Una variable booleana que se utiliza para comprobar si el servidor es posible.
	public boolean posible;
	// Una pila de números enteros.
	public Stack<Integer> piezas;
	// Una referencia al JLayeredPane que se usa para mostrar las piezas.
	public static JLayeredPane camadasRef;

	// un constructor
	public OrigenServidor(int n){
		cor = n;
		posible = false;
		this.dentro= 3;
		piezas = new Stack<Integer>();
		piezas.push(0);
		piezas.push(1);
		piezas.push(2);	
	}
}
