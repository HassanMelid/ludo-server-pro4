package servidor;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Es una clase que representa una casa en el tablero.
 */
public class CasaServidor {
	
	public int pos;
	public int x, y;
	public int[] n_pecas = {0, 0, 0, 0};
	public List<Stack<Integer>> piezas = new ArrayList<Stack<Integer>>();
	public boolean posible;
	public boolean nacer;
	public boolean pecaSaindo;
	
	// Un constructor para la clase CasaServidor.
	public CasaServidor(int n, int y_n, int x_n){
		this.pos= n;
		posible = false;
		nacer = false;
		pecaSaindo = false;
		x = x_n*47;
		y = y_n*47;
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
		piezas.add(new Stack<Integer>());
	}
	
	// Una función que se llama cuando un jugador aterriza en una casilla que está ocupada por otro
	// jugador. Quita la pieza del otro jugador del tablero y la devuelve a la casa del jugador.
	public void kill() {
		if(pos != 0 && pos != 12 && pos != 24 && pos != 36) {
			for(int i=0; i<4; i++) {
				if(n_pecas[i] > 0 && i != DadosServidor.turno) {
					// Mover las piezas de nuevo a la posición original.
					while(n_pecas[i] > 0) {
						
						PiezasServidor.coordPeca[i][piezas.get(i).peek()][0] = PiezasServidor.backup[i][piezas.get(i).peek()][0];
						PiezasServidor.coordPeca[i][piezas.get(i).peek()][1] = PiezasServidor.backup[i][piezas.get(i).peek()][1];
						PiezasServidor.posPeca[i][piezas.get(i).peek()] = -1;
						ServerLudo.mover_peca(i, piezas.get(i).peek(), PiezasServidor.backup[i][piezas.get(i).peek()][0], PiezasServidor.backup[i][piezas.get(i).peek()][1], 1);
						n_pecas[i]--;
						GridLogic.origens[i].dentro++;
						GridLogic.origens[i].piezas.push(piezas.get(i).peek());
						PiezasServidor.p_juntas[i][piezas.get(i).pop()] = 1;
					}
				}
			}
		}
	}
}
