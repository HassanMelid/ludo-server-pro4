package servidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Es una clase que maneja la conexión del cliente al servidor.
 */
public class ClientHandler implements Runnable {

	public Socket client;
	private BufferedReader in;
	public PrintWriter out;
	private int ID;
	
	// El constructor de la clase ClientHandler. Se utiliza para inicializar las variables de clase.
	public ClientHandler(Socket clientSocket, int id) throws IOException {
		ID = id;
		this.client = clientSocket;
		in = new BufferedReader(new InputStreamReader(client.getInputStream()));
		out = new PrintWriter(client.getOutputStream(), true);
	}

	/**
	 * Espera un mensaje del cliente y luego llama a la función interpretarMensagem() para interpretar el
	 * mensaje.
	 */
	@Override
	public void run() {
		String clientRequest;
		while(!ServerLudo.finJuego) {
			try {
				if((ServerLudo.statusJugadores[ServerLudo.turnoActual] == 0 && ServerLudo.esperarConexao == false)) {
					
					JugadorMaquina.jogarMaquina(ServerLudo.turnoActual);
				}
				else{
					if(ServerLudo.statusJugadores[ID] != 0) {
						clientRequest = in.readLine();
						interpretarMensagem(clientRequest);
					}
				}
			} catch (Exception e) {
				ServerLudo.atualizar_info(ServerLudo.nombre[ID] + " se desconecto. Una maquina fue adicionada en su lugar.");
				ServerLudo.statusJugadores[ID] = 0;
			}
		} 
		out.close();
	}
	
	// Una función que se utiliza para interpretar el mensaje enviado por el cliente.
	private void interpretarMensagem(String msg) throws Exception {
		if(msg.startsWith("INICIAR_JOGO")) {
			int id = (int)(msg.charAt(13) - '0');
			if(msg.charAt(15) == '0')
				ServerLudo.statusJugadores[id] = 1;
			else
				ServerLudo.statusJugadores[id] = 2;
			ServerLudo.outToAll("STATUS__JOGADORES " + ServerLudo.statusJugadores[0] + " " + ServerLudo.statusJugadores[1] + " " + ServerLudo.statusJugadores[2] + " " + ServerLudo.statusJugadores[3] + " 0");
			int terminar = 2;
			for(int i = 0; i < ServerLudo.qtConectada; i++)
			{
				if(ServerLudo.statusJugadores[i] <= terminar)
					terminar = ServerLudo.statusJugadores[i] ;
			}
			if(terminar == 2 && ServerLudo.qtConectada > 0) {
				ServerLudo.esperarConexao = false;
				if(ServerLudo.qtConectada<4) {
					Socket dummy = new Socket ("127.0.0.1", 9090);
					dummy.close();
				}
			}
			return;
		}
		// Comprobando si el mensaje empieza por "ROLAR__DADOS" y si lo hace, obtendrá el id del jugador y
		// comprobará si es el mismo del turno actual. Si es así, llamará a la función
		// `DadosServidor.girarDados()`
		if(msg.startsWith("ROLAR__DADOS")) {
			int idJogador = (int)(msg.charAt(13) - '0');
			if(idJogador == ServerLudo.turnoActual)
				DadosServidor.girarDados();
			return;
		}
		// Comprobando si el mensaje empieza por "CLICAR__CASA" y si lo hace, obtendrá el id del jugador y
		// comprobará si es el mismo del turno actual. Si es así, llamará a la función
		// `DadosServidor.girarDados()`.
		if(msg.startsWith("CLICAR__CASA")) {
			int idJogador = (int)(msg.charAt(13) - '0');
			int pos = (int)(msg.charAt(15) - '0') * 10;
			pos += (int)(msg.charAt(16) - '0');
			if(idJogador == ServerLudo.turnoActual)
				GridLogic.clickCasa(pos);
			return;
		}
		// Verificando si el mensaje comienza con "CLICA_ORIGEM" y si lo hace, obtendrá la identificación del
		// jugador y verificará si es el mismo que el turno actual. Si es así, llamará a la función
		// GridLogic.clickOrigem(idJogador).
		if(msg.startsWith("CLICA_ORIGEM")) {
			int idJogador = (int)(msg.charAt(13) - '0');
			if(idJogador == ServerLudo.turnoActual)
				GridLogic.clickOrigem(idJogador);
			return;
		}
		// Verificando si el mensaje comienza con "CLICA_CENTRO" y si lo hace, obtendrá la identificación del
		// jugador y verificará si es el mismo que el turno actual. Si es así, llamará a la función
		// GridLogic.clickCentro().
		if(msg.startsWith("CLICA_CENTRO")) {
			int idJogador = (int)(msg.charAt(13) - '0');
			if(idJogador == ServerLudo.turnoActual)
				GridLogic.clickCentro();
			return;
		}
		// Obtener el nombre del jugador y guardarlo en la matriz de nombres.
		if(msg.startsWith("ENVIAR__NOME")) {
			int idJogador = (int)(msg.charAt(13) - '0');
			ServerLudo.nombre[idJogador] = msg.substring(15, msg.length());
		}
	}
}
