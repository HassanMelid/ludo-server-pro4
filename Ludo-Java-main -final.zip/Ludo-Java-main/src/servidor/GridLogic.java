package servidor;


import java.util.Stack;

/**
 * Es una clase que contiene toda la lógica del juego.
 */
public class GridLogic {
	static CasaServidor camino[] = new CasaServidor[68];		//Vcetor con todas las casas del tablero
	static OrigenServidor origens[] = new OrigenServidor[4];
	static CentroServidor centro = new CentroServidor();
	static int[] cercaCentro = new int[4];
	static boolean movimientoIniciado = false;	//True cuando una pieza esta siendo movida de una casa para otra
	static int[][] index = {{-1, -1,	-1,	-1,	-1,	24,	-1,	23,	-1,	22,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	25,	-1,	58,	-1,	21,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	26,	-1,	59,	-1,	20,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	27,	-1,	60,	-1,	19,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1, -1,	-1,	28,	-1,	61,	-1,	18,	-1,	-1,	-1,	-1,	-1},
					 		{34, 33,	32,	31,	30,	29,	-1,	62,	-1,	17,	16,	15,	14,	13,	12},
					 		{-1, -1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1},
					 		{35, 63,	64,	65,	66,	67,	-1,	-1,	-1,	57,	56,	55,	54,	53,	11},
					 		{-1, -1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1},
					 		{36, 37,	38,	39,	40,	41,	-1,	52,	-1,	5,	6,	7,	8,	9,	10},
					 		{-1, -1,	-1,	-1,	-1,	42,	-1,	51,	-1,	4,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	43,	-1,	50,	-1,	3,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	44,	-1,	49,	-1,	2,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	45,	-1,	48,	-1,	1,	-1,	-1,	-1,	-1,	-1},
					 		{-1, -1,	-1,	-1,	-1,	46,	-1,	47,	-1,	0,	-1,	-1,	-1,	-1,	-1}};
	
	
	
	
	// Creando una nueva instancia de la clase PiezasServidor.
	static PiezasServidor camadaPiezas = new PiezasServidor();
	


	// Creación de la grilla del juego.
	public GridLogic() {
		
		for(int linea = 0; linea <15; linea++) {
			for(int col = 0; col<15; col++) {
				if((col==5 || col==7 || col==9)&&(linea<=5 || linea>=9)) {
					camino[index[linea][col]] = new CasaServidor(index[linea][col], linea, col);
				}
				else {
					if((linea==5 || linea==7 || linea==9)&&(col<5 || col>9)) {
						camino[index[linea][col]] = new CasaServidor(index[linea][col], linea, col);
					}
					else {
						if((col==5 || col==9)&&(linea==7)) {
							camino[index[linea][col]] = new CasaServidor(index[linea][col], linea, col);
						}
					}
				}
			}
		}


		// Creando una nueva instancia de la clase DadosServidor, que es un singleton.
		new DadosServidor();
		
		origens[0] = new OrigenServidor(0);
		origens[1] = new OrigenServidor(1);
		origens[2] = new OrigenServidor(2);
		origens[3] = new OrigenServidor(3);
	}
	
	/**
	 * Toma una posición y un turno y devuelve la posición de la misma pieza en la perspectiva del otro
	 * jugador
	 * 
	 * @param pos la posición de la pieza en el tablero
	 * @param turno 0 para amarillo, 1 para rojo
	 * @return La posición de la pieza en el tablero.
	 */
	public static int particular_real(int pos, int turno) {//0, amarelo -> 12
		if(pos >= 0 && pos < (12*(4 - turno)))
			return (pos + turno*12);
		if(pos >= (12*(4 - turno)) && pos < 48)
			return (pos - (12*(4 - turno)));
		return (pos + turno*5);
	}
	
	/**
	 * Toma una posición y un giro y devuelve la posición de la pieza en el tablero
	 * 
	 * @param pos la posición de la pieza
	 * @param turno 0, 1, 2, 3
	 * @return La posición de la pieza en el tablero.
	 */
	public static int real_particular(int pos, int turno) {//12, amarelo -> 0
		if(pos >= turno*12 && pos < 48)
			return (pos - turno*12);
		if(pos < turno*12)
			return (pos + 12*(4 - turno));
		return (pos - turno*5);
	}
	
	/**
	 * Toma una posición y un número de pasos, y devuelve la posición que está n pasos por delante de la
	 * posición original
	 * 
	 * @param pos la posición del jugador
	 * @param n número de pasos para avanzar
	 * @return La posición del jugador después de moverse n pasos.
	 */
	public static int avancar_casa(int pos, int n) {
		return (particular_real(real_particular(pos, DadosServidor.turno) + n, DadosServidor.turno));
	}
	
	// Comprobación de colisiones entre piezas.
	public static void verificar_colisao() {
		int[][] shift = {{1, 1}, {1, -1}, {-1, -1}, {-1, 1}};
		for(int k = 0; k < 68; k++) {
			if(camino[k].n_pecas[0] + camino[k].n_pecas[1] + camino[k].n_pecas[2] + camino[k].n_pecas[3] > 1) {
				for(int i = 0; i < 4; i++) {
					Stack<Integer> aux = new Stack<Integer>();
					for(int j = 0; j < camino[k].n_pecas[i]; j++) {
						PiezasServidor.coordPeca[i][camino[k].piezas.get(i).peek()][0] = camino[k].x + 12*shift[i][0];
						PiezasServidor.coordPeca[i][camino[k].piezas.get(i).peek()][1] = camino[k].y + 12*shift[i][1];
						ServerLudo.mover_peca(i, camino[k].piezas.get(i).peek(), camino[k].x + 12*shift[i][0], camino[k].y + 12*shift[i][1], camino[k].n_pecas[i]);
						aux.push(camino[k].piezas.get(i).pop());
					}
					for(int j = 0; j < camino[k].n_pecas[i]; j++) {
						camino[k].piezas.get(i).push(aux.peek());
						PiezasServidor.p_juntas[i][aux.pop()] = camino[k].n_pecas[i];
					}
				}
			}
			// Moviendo las piezas en el tablero.
			else {
				for(int i = 0; i < 4; i++) {
					Stack<Integer> aux = new Stack<Integer>();
					for(int j = 0; j < camino[k].n_pecas[i]; j++) {
						PiezasServidor.coordPeca[i][camino[k].piezas.get(i).peek()][0] = camino[k].x;
						PiezasServidor.coordPeca[i][camino[k].piezas.get(i).peek()][1] = camino[k].y;
						ServerLudo.mover_peca(i, camino[k].piezas.get(i).peek(), camino[k].x, camino[k].y, camino[k].n_pecas[i]);
						aux.push(camino[k].piezas.get(i).pop());
					}
					for(int j = 0; j < camino[k].n_pecas[i]; j++) {
						camino[k].piezas.get(i).push(aux.peek());
						PiezasServidor.p_juntas[i][aux.pop()] = camino[k].n_pecas[i];
					}
				}
			}
		}
	}
 	
	// Comprobar si el jugador tiene una pieza en el centro del tablero. Si es así, comprueba si el
	// jugador tiene un 6 o si todas sus piezas están en la recta final. Si es así, marca los dados como
	// usados.
	public static void verificar_jogada() {
		switch (cercaCentro[DadosServidor.turno]) {
		case 3:
			if(DadosServidor.dado1 == 6 || ((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
					(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
					(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado1 > 53)))
				DadosServidor.dado1usado = true;
			if(DadosServidor.dado2 == 6 || ((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
					(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
					(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado2 > 53)))
				DadosServidor.dado2usado = true;
			break;
		// Comprobar si al jugador le queda una sola pieza y si el dado tirado es un 6 o si la pieza está en
		// casa y el dado tirado es mayor que el número de espacios que quedan hasta la línea de meta. Si
		// alguna de estas condiciones es verdadera, el dado se marca como usado.
		case 2:
			if(centro.n_pecas[DadosServidor.turno] == 1) {
				if(DadosServidor.dado1 == 6 || ((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado1 > 53)))
					DadosServidor.dado1usado = true;
				if(DadosServidor.dado2 == 6 || ((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado2 > 53)))
					DadosServidor.dado2usado = true;
			}
			// Comprobando si el jugador puede mover alguna de sus piezas.
			if(origens[DadosServidor.turno].dentro == 1) {
				if((DadosServidor.dado1 == 6 && !DadosServidor.dado1usado) || (DadosServidor.dado2 == 6 && !DadosServidor.dado2usado)) {
					//Ele pode gastar os dois dados na peca que ta fora.
				}
				else {
					if((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado1 > 53))
							DadosServidor.dado1usado = true;
					if((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado2 > 53))
							DadosServidor.dado2usado = true;
				}
			}
			break;
		// Comprobar si el jugador ha sacado un 6 y si lo ha hecho, es comprobar si tiene alguna pieza en la
		// posición inicial. Si lo ha hecho, puede mover una pieza fuera de la posición inicial.
		case 1:
			if(centro.n_pecas[DadosServidor.turno] == 2) {
				if(DadosServidor.dado1 == 6 || ((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
										(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
										(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado1 > 53)))
					DadosServidor.dado1usado = true;
				if(DadosServidor.dado2 == 6 || ((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
										(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
										(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado2 > 53)))
					DadosServidor.dado2usado = true;
			}
			if(origens[DadosServidor.turno].dentro == 2) {
				if((DadosServidor.dado1 == 6 && !DadosServidor.dado1usado) || (DadosServidor.dado2 == 6 && !DadosServidor.dado2usado)) {
					//El puede gastar los dos dados en las piezas que esta fuera.
				}
				// Comprobando si el jugador puede mover alguna de sus piezas con los valores de los dados. Si no
				// puede, entonces el valor del dado se marca como usado.
				else {
					if((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado1 > 53))
							DadosServidor.dado1usado = true;
					if((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado2 > 53))
							DadosServidor.dado2usado = true;
				}
			}
			// Comprobando si el jugador puede mover alguna de sus piezas.
			if(centro.n_pecas[DadosServidor.turno] == 1 && origens[DadosServidor.turno].dentro == 1) {
				if((DadosServidor.dado1 == 6 && !DadosServidor.dado1usado) || (DadosServidor.dado2 == 6 && !DadosServidor.dado2usado)) {
					//El puede gastar los dos dados en la pieza que esta fuera.
				}
				// Comprobando si el jugador puede mover alguna de sus piezas. Si no puede, entonces el dado se
				// marca como usado.
				else {
					if((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado1 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado1 > 53))
							DadosServidor.dado1usado = true;
					if((PiezasServidor.posPeca[DadosServidor.turno][0] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][0], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][1] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][1], DadosServidor.turno) + DadosServidor.dado2 > 53) &&
						(PiezasServidor.posPeca[DadosServidor.turno][2] == -1 ||  real_particular(PiezasServidor.posPeca[DadosServidor.turno][2], DadosServidor.turno) + DadosServidor.dado2 > 53))
							DadosServidor.dado2usado = true;
				}
			}
			// Comprobar si el jugador tiene alguna pieza en el tablero. Si no, comprueba si el jugador sacó un
			// 6. Si no, pone los dados en usados.
			break;
		case 0:
			if((PiezasServidor.posPeca[DadosServidor.turno][0] == -1) && (PiezasServidor.posPeca[DadosServidor.turno][1] == -1) && (PiezasServidor.posPeca[DadosServidor.turno][2] == -1)) {
				if(DadosServidor.dado1 != 6 && DadosServidor.dado2 != 6) {
					DadosServidor.dado1usado = DadosServidor.dado2usado = true;
				}
			}
		}
		ServerLudo.atualizar_dados(DadosServidor.dado1, DadosServidor.dado1usado, DadosServidor.dado2, DadosServidor.dado2usado);
		if(DadosServidor.dado1usado && DadosServidor.dado2usado)
			DadosServidor.proxTurno();
	}
	
	// Un método que se llama cuando un jugador hace clic en una casa.
	public static void nascerCasa(int pos) {
		camino[pos].nacer = false;
		camino[pos].n_pecas[DadosServidor.turno]++;
		//camino[pos].ColorNormal();
		camino[pos].piezas.get(DadosServidor.turno).push(origens[DadosServidor.turno].piezas.pop());
		//origens[DadosServidor.turno].ColorNormal();
		origens[DadosServidor.turno].dentro--;
		movimientoIniciado = false;
		PiezasServidor.posPeca[DadosServidor.turno][camino[pos].piezas.get(DadosServidor.turno).peek()] = pos;
		ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
		ServerLudo.colorir_casa(pos, 0);
		ServerLudo.disponivel_origem(origens[DadosServidor.turno].posible, movimientoIniciado);
		ServerLudo.colorir_origem(0);
	}
	
	/**
	 * Cambia el color del cuadrado en el tablero.
	 * 
	 * @param avanco la posición de la pieza
	 * @param posible si el jugador puede moverse a esta posición
	 * @param colorir 0 = sin color, 1 = verde, 2 = rojo, 3 = azul, 4 = amarillo
	 */
	public static void avancoCasa(int avanco, boolean posible, int colorir) {
		camino[avanco].posible = posible;
		ServerLudo.disponivel_casa(avanco, camino[avanco].posible, camino[avanco].nacer, camino[avanco].pecaSaindo, movimientoIniciado);
		ServerLudo.colorir_casa(avanco, colorir);
	}
	
	/**
	 * > Esta función se utiliza para cambiar el estado del centro del tablero
	 * 
	 * @param posible verdadero si el jugador puede moverse hacia el centro, falso de lo contrario
	 * @param colorir 0 = sin color, 1 = verde, 2 = rojo, 3 = azul, 4 = amarillo
	 */
	public static void avancoCentro(boolean posible, int colorir) {
		centro.posible = posible;
		//mensaje relativo al centro
		ServerLudo.disponivel_centro(centro.posible, movimientoIniciado);
		ServerLudo.colorir_centro(colorir);
	}
	
	// Verificando si el jugador tiene un 6 y si lo tiene, generará una nueva pieza.
	public static void clickCasa(int pos) {
		int avanco = 0;
		if(camino[pos].nacer == true) {
			if(!DadosServidor.dado1usado && DadosServidor.dado1 == 6) {
				nascerCasa(pos);
				DadosServidor.dado1usado = true;
				verificar_jogada();
				verificar_colisao();
				return;
			}
			// Comprobando si el jugador está en la posición de Java. Si es así, llamará a la función
			// nascerCasa(), que creará una casa en la posición del jugador. También establecerá la variable
			// dado2usado en verdadero, lo que significa que se ha utilizado el segundo dado. Luego llamará a
			// las funciones verificar_jogada() y verificar_colisao().
			else {
				nascerCasa(pos);
				DadosServidor.dado2usado = true;
				verificar_jogada();
				verificar_colisao();
				return;
			}
		}
		// Comprobando si el jugador puede mover la pieza a la siguiente casa.
		if(camino[pos].posible) {
			//avanco -> pos
			avanco = avancar_casa(pos, -DadosServidor.dado1);
			if(avanco >= 0 && !DadosServidor.dado1usado && camino[avanco].pecaSaindo) {
				//camino[pos].ColorNormal();
				camino[pos].posible = false;
				camino[pos].n_pecas[DadosServidor.turno]++;
				camino[pos].piezas.get(DadosServidor.turno).push(camino[avanco].piezas.get(DadosServidor.turno).pop());
				camino[avanco].n_pecas[DadosServidor.turno]--;
				//camino[avanco].ColorNormal();
				movimientoIniciado = false;
				camino[avanco].pecaSaindo = false;
				//mensaje relativo a la casa actual: pos
				ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
				ServerLudo.colorir_casa(pos, 0);
				//mensaje relativo a la casa posterior: avancar_casa(pos, -Dados.dado1)
				ServerLudo.disponivel_casa(avanco, camino[avanco].posible, camino[avanco].nacer, camino[avanco].pecaSaindo, movimientoIniciado);
				ServerLudo.colorir_casa(avanco, 0);
				
				//avanzo
				// Comprobando si la suma de los dados es inferior a 53. Si lo es, moverá al jugador a la siguiente
				// posición.
				if((real_particular(pos, DadosServidor.turno) - DadosServidor.dado1 + DadosServidor.dado2) < 53) {
					avanco = avancar_casa(pos, -DadosServidor.dado1+DadosServidor.dado2);
					avancoCasa(avanco, false, 0);
				}
				// Comprobando si la suma de la tirada de dados y la posición actual es inferior a 53. Si lo es,
				// avanza el jugador por el valor de la tirada de dados.
				if(real_particular(pos, DadosServidor.turno) + DadosServidor.dado2 < 53) {
					avanco = avancar_casa(pos, +DadosServidor.dado2);
					avancoCasa(avanco, false, 0);
				}
				DadosServidor.dado1usado = true;
				PiezasServidor.posPeca[DadosServidor.turno][camino[pos].piezas.get(DadosServidor.turno).peek()] = pos;
				
				avancoCentro(false, 0);
				
				camino[pos].kill();
				if(pos >= 48) {
					cercaCentro[DadosServidor.turno] = 0;
					for(int i=48; i<53; i++) {
						cercaCentro[DadosServidor.turno] += camino[particular_real(i, DadosServidor.turno)].n_pecas[DadosServidor.turno];
					}
				}
				verificar_jogada();
				
			}
			// Comprobando si el jugador puede mover la pieza a la siguiente casa.
			else {
				avanco = avancar_casa(pos, -DadosServidor.dado2);
				if(avanco >= 0 && !DadosServidor.dado2usado && camino[avanco].pecaSaindo) {
					//camino[pos].ColorNormal();
					camino[pos].posible = false;
					camino[pos].n_pecas[DadosServidor.turno]++;
					camino[pos].piezas.get(DadosServidor.turno).push(camino[avanco].piezas.get(DadosServidor.turno).pop());
					camino[avanco].n_pecas[DadosServidor.turno]--;
					//camino[avanco].ColorNormal();
					movimientoIniciado = false;
					camino[avanco].pecaSaindo = false;
					//mensaje relativo a la casa actual: pos
					ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
					ServerLudo.colorir_casa(pos, 0);
					//mensaje relativo a la casa posterior: avanco
					ServerLudo.disponivel_casa(avanco, camino[avanco].posible, camino[avanco].nacer, camino[avanco].pecaSaindo, movimientoIniciado);
					ServerLudo.colorir_casa(avanco, 0);
					
					// Comprobando si el jugador está en una posición determinada y si la suma de los dos dados es
					// menor que 53. Si es así, avanza al jugador a la siguiente posición.
					if(real_particular(pos, DadosServidor.turno) - DadosServidor.dado2 + DadosServidor.dado1 < 53) {
						avanco = avancar_casa(pos, -DadosServidor.dado2+DadosServidor.dado1);
						avancoCasa(avanco, false, 0);
					}
					// Comprobando si la suma del real_particular y el dado1 es menor que 53. Si lo es, está avanzando
					// la posición del jugador por el valor de dado1.
					if(real_particular(pos, DadosServidor.turno) + DadosServidor.dado1 < 53) {
						avanco = avancar_casa(pos, +DadosServidor.dado1);
						avancoCasa(avanco, false, 0);
					}
					DadosServidor.dado2usado = true;
					PiezasServidor.posPeca[DadosServidor.turno][camino[pos].piezas.get(DadosServidor.turno).peek()] = pos;
					
					avancoCentro(false, 0);
					
					camino[pos].kill();
					if(pos >= 48) {
						cercaCentro[DadosServidor.turno] = 0;
						for(int i = 48; i < 53; i++) {
							cercaCentro[DadosServidor.turno] += camino[particular_real(i, DadosServidor.turno)].n_pecas[DadosServidor.turno];
						}
					}
					verificar_jogada();
				}
				// Mover la pieza de una posición a otra.
				else {
					avanco = avancar_casa(pos, -DadosServidor.dado1-DadosServidor.dado2);
					//camino[pos].ColorNormal();
					camino[pos].posible = false;
					camino[pos].n_pecas[DadosServidor.turno]++;
					camino[pos].piezas.get(DadosServidor.turno).push(camino[avanco].piezas.get(DadosServidor.turno).pop());
					camino[avanco].n_pecas[DadosServidor.turno]--;
					//camino[avanco].ColorNormal();
					movimientoIniciado = false;
					camino[avanco].pecaSaindo = false;
					//mensaje relativo a la casa actual: pos
					ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
					ServerLudo.colorir_casa(pos, 0);
					//mensaje relativo a la casa posterior: avanco
					ServerLudo.disponivel_casa(avanco, camino[avanco].posible, camino[avanco].nacer, camino[avanco].pecaSaindo, movimientoIniciado);
					ServerLudo.colorir_casa(avanco, 0);
					
					avanco = avancar_casa(pos, -DadosServidor.dado1);
					avancoCasa(avanco, false, 0);
					
					avanco = avancar_casa(pos, -DadosServidor.dado2);
					avancoCasa(avanco, false, 0);
					
					DadosServidor.dado1usado = DadosServidor.dado2usado = true;
					PiezasServidor.posPeca[DadosServidor.turno][camino[pos].piezas.get(DadosServidor.turno).peek()] = pos;
					
					avancoCentro(false, 0);
					
					camino[pos].kill();
					if(pos >= 48) {
						cercaCentro[DadosServidor.turno] = 0;
						for(int i=48; i<53; i++) {
							cercaCentro[DadosServidor.turno] += camino[particular_real(i, DadosServidor.turno)].n_pecas[DadosServidor.turno];
						}
					}
					ServerLudo.atualizar_dados(DadosServidor.dado1, DadosServidor.dado1usado, DadosServidor.dado2, DadosServidor.dado2usado);
					DadosServidor.proxTurno();
				}
			}
		// Comprobar si el jugador tiene una pieza en la posición actual y si no se ha utilizado el dado. Si
		// el jugador tiene una pieza en la posición actual y no se ha utilizado el dado, comprueba si la
		// suma de la posición actual y los dados es menor o igual a 53. Si la suma es menor o igual a 53, se
		// comprueba si la suma es igual a 53. Si la suma es igual a 53, pone a true la variable pieceSaindo,
		// pone a true la variable movimientoIniciado y envía un mensaje al servidor
		}
		else {
			if(!movimientoIniciado && camino[pos].n_pecas[DadosServidor.turno] > 0) {
				if(!DadosServidor.dado1usado && real_particular(pos, DadosServidor.turno) + DadosServidor.dado1 <= 53) {
					if(real_particular(pos, DadosServidor.turno) + DadosServidor.dado1 == 53) {
						//tratar
						//camino[pos].ColorSelected();
						camino[pos].pecaSaindo = true;
						//centro.Selected();
						movimientoIniciado = true;
						//mensaje relativo a la casa actual: pos
						ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
						ServerLudo.colorir_casa(pos, 2);
						//mensaje relativo al
						centro.posible = true;
						ServerLudo.disponivel_centro(centro.posible, movimientoIniciado);
						ServerLudo.colorir_centro(1);
						
					}
					// El código anterior es parte del código responsable del movimiento de las piezas en el juego.
					else {
						//camino[pos].ColorSelected();
						//camino[avanco].Colorposible();
						movimientoIniciado = true;
						camino[pos].pecaSaindo = true;

						//mensaje relativo a la casa actual: pos
						ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
						ServerLudo.colorir_casa(pos, 2);
						
						avanco = avancar_casa(pos, +DadosServidor.dado1);
						avancoCasa(avanco, true, 1);
					}
				}
				// Comprobando si no se ha utilizado el segundo dado y si la suma del segundo dado y la posición
				// actual es inferior a 53. Si lo es, está comprobando si la suma es igual a 53. Si lo es, está
				// poniendo el pecaSaindo variable a true y la variable movimientoIniciado a true. Luego llama al
				// método disponivel_casa con la posición actual, la variable posible, la variable nascer, la
				// variable pecaSaindo y la variable movimientoIniciado.
				if(!DadosServidor.dado2usado && real_particular(pos, DadosServidor.turno) + DadosServidor.dado2 <= 53) {
					if(real_particular(pos, DadosServidor.turno) + DadosServidor.dado2 == 53) {
						//tratar
						//camino[pos].ColorSelected();
						camino[pos].pecaSaindo = true;
						//centro.Selected();
						movimientoIniciado = true;
						
						//mensaje relativo a la casa actual: pos
						ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
						ServerLudo.colorir_casa(pos, 2);

						//mensaje relativo al centro
						avancoCentro(true, 1);
					}
					// El código anterior verifica si el jugador está en el hogar o no. Si el jugador está en el
					// hogar, entonces el jugador puede mudarse fuera del hogar.
					else {
						//camino[pos].ColorSelected();
						//camino[avanco].Colorposible();
						movimientoIniciado = true;
						camino[pos].pecaSaindo = true;

						//mensaje relativo a la casa actual: pos
						ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
						ServerLudo.colorir_casa(pos, 2);
						
						avanco = avancar_casa(pos, +DadosServidor.dado2);
						avancoCasa(avanco, true, 1);
					}
				}
				// Comprobar si se ha utilizado el dado y si la suma de los dados y la posición de la pieza es
				// inferior a 53.
				if(!DadosServidor.dado1usado && !DadosServidor.dado2usado && real_particular(pos, DadosServidor.turno) + DadosServidor.dado1 + DadosServidor.dado2 <= 53) {
					if(real_particular(pos, DadosServidor.turno) + DadosServidor.dado1 + DadosServidor.dado2 == 53) {
						//tratar
						//camino[pos].ColorSelected();
						camino[pos].pecaSaindo = true;
						//centro.Selected();
						movimientoIniciado = true;
						
						//mensaje relativo a la casa actual: pos
						ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
						ServerLudo.colorir_casa(pos, 2);
						//mensaje relativo al
						avancoCentro(true, 1);
					}
					// El código anterior verifica si el jugador está en el hogar y si el jugador está en el hogar,
					// luego verifica si el jugador está en el hogar y si el jugador está en el hogar, luego verifica
					// si el jugador está en el hogar y si el jugador está en la casa, entonces está verificando si el
					// jugador está en la casa y si el jugador está en la casa, entonces está verificando si el
					// jugador está en la casa y si el jugador está en la casa, entonces está verificando si el
					// jugador está en el hogar y si el jugador está en el hogar, entonces está verificando si
					else {
						//camino[pos].ColorSelected();
						//camino[avanco].Colorposible();
						movimientoIniciado = true;
						camino[pos].pecaSaindo = true;

						//mensaje relativo a la casa actual: pos
						ServerLudo.disponivel_casa(pos, camino[pos].posible, camino[pos].nacer, camino[pos].pecaSaindo, movimientoIniciado);
						ServerLudo.colorir_casa(pos, 2);
						
						avanco = avancar_casa(pos, +DadosServidor.dado1+DadosServidor.dado2);
						avancoCasa(avanco, true, 1);
					}
				}
			}
			// Comprobar si el jugador ha movido la pieza o no.
			else {
				movimientoIniciado = false;
				for(int i = 0; i < 68; i++) {
					if(camino[i].posible == true || camino[i].pecaSaindo == true || camino[i].nacer == true) {
						avanco = i;
						//camino[i].ColorNormal();
						camino[i].posible = false;
						camino[i].pecaSaindo = false;
						camino[i].nacer = false;
						//mensaje relativo a la casa posterior: avanco
						ServerLudo.disponivel_casa(avanco, camino[avanco].posible, camino[avanco].nacer, camino[avanco].pecaSaindo, movimientoIniciado);
						ServerLudo.colorir_casa(avanco, 0);
					}
				}
				//origens[DadosServidor.turno].ColorNormal();
				ServerLudo.disponivel_origem(origens[DadosServidor.turno].posible, movimientoIniciado);
				ServerLudo.colorir_origem(0);
				
				//centro.Normal();
				centro.posible = false;	
				ServerLudo.disponivel_centro(centro.posible, movimientoIniciado);
				ServerLudo.colorir_centro(0);
			}
		}
		verificar_colisao();
	}
	
	// Un método que se llama cuando un jugador mueve una pieza al centro del tablero.
	public static void playCentro(int avanco) {
		centro.posible = false;
		centro.n_pecas[DadosServidor.turno]++;
		centro.piezas.get(DadosServidor.turno).push(camino[avanco].piezas.get(DadosServidor.turno).pop());
		camino[avanco].n_pecas[DadosServidor.turno]--;
		camino[avanco].pecaSaindo = false;
		movimientoIniciado = false;
		
		//mensaje relativo a la casa avanco
		ServerLudo.disponivel_casa(avanco, camino[avanco].posible, camino[avanco].nacer, camino[avanco].pecaSaindo, movimientoIniciado);
		ServerLudo.colorir_casa(avanco, 0);
		//mensaje relativo al
		ServerLudo.disponivel_centro(centro.posible, movimientoIniciado);
		ServerLudo.colorir_centro(0);
		
		// Al verificar si la próxima casa está disponible, si lo está, configurará la próxima casa como no
		// disponible y enviará un mensaje al cliente.
		for(int i = 0; i < 68; i++) {
			if(camino[i].posible == true || camino[i].pecaSaindo == true || camino[i].nacer == true) {
				avanco = i;
				camino[i].posible = false;
				camino[i].pecaSaindo = false;
				camino[i].nacer = false;
				//mensaje relativo a la casa posterior: avanco
				ServerLudo.disponivel_casa(avanco, camino[avanco].posible, camino[avanco].nacer, camino[avanco].pecaSaindo, movimientoIniciado);
				ServerLudo.colorir_casa(avanco, 0);
			}
		}
		
		PiezasServidor.coordPeca[DadosServidor.turno][centro.piezas.get(DadosServidor.turno).peek()][0] = CentroServidor.posFinal[DadosServidor.turno][centro.piezas.get(DadosServidor.turno).peek()][0];
		PiezasServidor.coordPeca[DadosServidor.turno][centro.piezas.get(DadosServidor.turno).peek()][1] = CentroServidor.posFinal[DadosServidor.turno][centro.piezas.get(DadosServidor.turno).peek()][1];
		PiezasServidor.posPeca[DadosServidor.turno][centro.piezas.get(DadosServidor.turno).peek()] = -1;
		ServerLudo.mover_peca(DadosServidor.turno, centro.piezas.get(DadosServidor.turno).peek(), CentroServidor.posFinal[DadosServidor.turno][centro.piezas.get(DadosServidor.turno).peek()][0], CentroServidor.posFinal[DadosServidor.turno][centro.piezas.get(DadosServidor.turno).peek()][1], 1);

	}
	
	// Comprobar si el jugador puede mover una pieza del centro al tablero.
	public static void clickCentro() {
		int avanco = -1;
		if((53 - DadosServidor.dado1) >= 47 && !DadosServidor.dado1usado && camino[particular_real(53 - DadosServidor.dado1, DadosServidor.turno)].pecaSaindo) {
			avanco = particular_real(53 - DadosServidor.dado1, DadosServidor.turno);
			playCentro(avanco);
			DadosServidor.dado1usado = true;
		}
		// Comprobar si el jugador puede mover una pieza del centro al tablero.
		else {
			if((53 - DadosServidor.dado2) >= 47 && !DadosServidor.dado2usado && camino[particular_real(53 - DadosServidor.dado2, DadosServidor.turno)].pecaSaindo) {
				avanco = particular_real(53 - DadosServidor.dado2, DadosServidor.turno);
				playCentro(avanco);
				DadosServidor.dado2usado = true;
			}
			// Comprobando si el jugador está en la cárcel. Si es así, comprobará si tiene un doble. Si lo ha
			// hecho, lo sacará de la cárcel. Si no lo hace, comprobará si tiene una tarjeta para salir de la
			// cárcel. Si lo ha hecho, lo sacará de la cárcel. Si no lo hace, comprobará si tiene un doble. Si
			// lo ha hecho, lo sacará de la cárcel. Si no lo hace, comprobará si tiene una tarjeta para salir de
			// la cárcel. Si lo tiene, es
			else {
				avanco = particular_real(53 - DadosServidor.dado1 - DadosServidor.dado2, DadosServidor.turno);
				playCentro(avanco);
				DadosServidor.dado1usado = DadosServidor.dado2usado = true;
			}
		}
		cercaCentro[DadosServidor.turno] = 0;
		for(int i = 48; i < 53; i++) {
			cercaCentro[DadosServidor.turno] += camino[particular_real(i, DadosServidor.turno)].n_pecas[DadosServidor.turno];
		}
		if(centro.n_pecas[DadosServidor.turno] == 3)
		{
			//Fin del Juego
			ServerLudo.mensagem_controle(2, DadosServidor.turno);
		}
		ServerLudo.atualizar_dados(DadosServidor.dado1, DadosServidor.dado1usado, DadosServidor.dado2, DadosServidor.dado2usado);
		verificar_colisao();
		verificar_jogada();
	}
	
	// Poniendo el origem a verdadero y el avanco a verdadero.
	public static void playOrigem(int cor, int avanco) {
		camino[avanco].nacer = true;
		movimientoIniciado = true;
		origens[cor].posible = true;
		
		ServerLudo.disponivel_origem(origens[cor].posible, movimientoIniciado);
		ServerLudo.colorir_origem(1);
		
		//mensaje relativo a la casa avanco
		ServerLudo.disponivel_casa(avanco, camino[avanco].posible, camino[avanco].nacer, camino[avanco].pecaSaindo, movimientoIniciado);
		ServerLudo.colorir_casa(avanco, 1);
	}
	
	// Comprobando si el jugador ha sacado un 6 y si lo ha hecho, está comprobando si tiene alguna pieza
	// en el origen. Si lo hace, está comprobando si ya ha movido alguna pieza y si es su turno. Si se
	// cumplen todas estas condiciones, está llamando a la función playOrigem.
	public static void clickOrigem(int cor) {
		int avanco = 0;
		if(DadosServidor.dado1 == 6 && !DadosServidor.dado1usado && !movimientoIniciado && origens[cor].dentro > 0 && DadosServidor.turno == cor) {
			avanco = particular_real(0, DadosServidor.turno);
			playOrigem(cor, avanco);
		}
		else if(DadosServidor.dado2 == 6 && !DadosServidor.dado2usado && !movimientoIniciado && origens[cor].dentro>0 && DadosServidor.turno == cor) {
			avanco = particular_real(0, DadosServidor.turno);
			playOrigem(cor, avanco);
		}
		origens[cor].posible = false;
	}
}


