package servidor;

/**
 * Es una clase que hace que el jugador de la computadora mueva una pieza al centro del tablero.
 */
public class JugadorMaquina {
	
	public static void avancarCentro(int miTurno) throws InterruptedException {
		for(int i = 0; i < 3; i++) {
			if(PiezasServidor.posPeca[miTurno][i] != -1) {
				GridLogic.clickCasa(PiezasServidor.posPeca[miTurno][i]);
				if(GridLogic.centro.posible && GridLogic.movimientoIniciado) {
					Thread.sleep(1000);
					GridLogic.clickCentro();
					Thread.sleep(500);
				}
			}
		}
	}
	
	// Un método que hace que el jugador de la computadora mueva una pieza fuera del origen.
	public static void sairOrigem(int miTurno) throws InterruptedException {
		GridLogic.clickOrigem(miTurno);
		int avanco = GridLogic.particular_real(0, DadosServidor.turno);
		if(GridLogic.movimientoIniciado && GridLogic.camino[avanco].nacer == true) {
			Thread.sleep(1000);
			GridLogic.clickCasa(avanco);
			Thread.sleep(500);
		}
		
		// Un método que hace que el jugador de la computadora mueva una pieza fuera del origen.
		GridLogic.clickOrigem(miTurno);
		avanco = GridLogic.particular_real(0, DadosServidor.turno);
		if(GridLogic.movimientoIniciado && GridLogic.camino[avanco].nacer == true) {
			Thread.sleep(1000);
			GridLogic.clickCasa(avanco);
			Thread.sleep(500);
		}
	}
	
	// Un método que hace que el jugador de la computadora mueva una pieza fuera del origen.
	public static void avancarCasa(int miTurno) throws InterruptedException {
		for(int k = 0; k < 2; k++) {
			for(int i = 0; i < 3; i++) {
				int pos = PiezasServidor.posPeca[miTurno][i];
				if(pos != -1) {
					GridLogic.clickCasa(pos);
					for(int j = 67; j >= 0; j--) {
						if(GridLogic.camino[j].posible) {
							int avanco = j;
							Thread.sleep(1000);
							GridLogic.clickCasa(avanco);
							Thread.sleep(500);
						}
					}
				}
			}
		}
	}
	
	// Un método que hace que el jugador de la computadora mueva una pieza al centro del tablero.
	public static void jogarMaquina(int miTurno) {
		//Rota los dados para iniciar la jugada
		try {
			while(miTurno == ServerLudo.turnoActual) {
				DadosServidor.girarDados();
				Thread.sleep(2000);
				avancarCentro(miTurno);

				sairOrigem(miTurno);

				avancarCasa(miTurno);
			}
		}
		catch (InterruptedException e) {
		    e.printStackTrace();
		}
	}
}
